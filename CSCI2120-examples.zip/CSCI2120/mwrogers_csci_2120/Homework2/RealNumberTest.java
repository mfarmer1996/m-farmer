import org.junit.Before;
import java.util.Random;
import org.junit.Test;
import static org.junit.Assert.*;

public class RealNumberTest {
    /**
     * Variable Declaration.
     */
    private static RealNumber someNumber, other, one, two, three, zero;
    public static final float EPSILON = ComplexNumberTest.EPSILON;


    /**
     * Initialize variables.
     */
    @Before
    public void initialize() {
        Random rand = new Random();
        this.one = new RealNumber(1.0f);
        this.other = new RealNumber(2.0f);
        this.someNumber = new RealNumber(5.0f);
        this.two = new RealNumber(2.0f);
        this.three = new RealNumber(3.0f);
        this.zero = new RealNumber(0.0f);

    }


    @Test
    public void testIsGreaterThan(){
        assertTrue(someNumber.isGreaterThan(other));
        assertTrue(two.isGreaterThan(one));
        assertTrue(three.isGreaterThan(two));
        assertTrue(one.isGreaterThan(zero));

    }

    @Test
    public void testIsLessThan(){
        assertTrue(zero.isLessThan(one));
        assertTrue(one.isLessThan(two));
        assertTrue(two.isLessThan(three));
        assertTrue(other.isLessThan(someNumber));
    }

    @Test
    public void testGetBShouldReturnZero(){
        assertEquals(zero.getB(),0.0f,EPSILON);
        assertEquals(three.getB(),0.0f,EPSILON);
        assertEquals(someNumber.getB(),0.0f,EPSILON);


    }
    @Test
    public void testToString()
    {
        assertEquals("5.00", someNumber.toString());
        assertEquals("0.00", zero.toString());
        assertEquals("3.00",three.toString());
    }

}