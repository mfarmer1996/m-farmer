import java.lang.ArithmeticException;   //import Arithmetic Exception to access throwable

/**
 * Class ComplexNumber allows manipulation of the instance variables
 * float a and float b which make up the real and imaginary parts (respectively)
 * of a complex number.
 *
 * @author Michael Rogers
 */
public class ComplexNumber
{
    /**The real part of the Complex Number.*/
    protected final float a;
    /**The imaginary part of the Complex Number.*/
    private final float b;

    /**
     * Constructs a new instance of ComplexNumber with the given
     * real parts a and imaginary parts b.
     *
     * @param a The real part.
     * @param b The imaginary part.
     */
    public ComplexNumber(float a, float b)
    {
        //Constructs a new instance of the real part of a Complex Number.
        this.a = a;
        //Constructs a new instance of the imaginary part of a Complex Number.
        this.b = b;
    }

    /**
     * Returns the result of this complex number added to
     * another.
     *
     * @param other The complex number to add.
     * @return The result of this + other.
     */
    public ComplexNumber add(ComplexNumber other)
    {
        //declare new temp float newA equal to the calculation for addition for a
        float newA = this.a + other.a;
        //declare new temp float newB equal to the calculation for addition for b
        float newB = this.b + other.b;
        //return the new complex number respresenting the sum of this and other
        return new ComplexNumber(newA, newB);
    }

    /**
     * Returns the result of this complex number subtracted
     * by another.
     *
     * @param other The complex number to subtract.
     * @return The result of this - other.
     */
    public ComplexNumber subtract(ComplexNumber other)
    {
        //declare new temp float newA equal to the calculation for subtraction for a
        float newA = this.a - other.a;
        //declare new temp float newB equal to the calculation for subtraction for b
        float newB = this.b - other.b;
        //return the new complex number respresenting the difference of this and other
        return new ComplexNumber(newA, newB);
    }

    /**
     * Returns the product of this complex number multiplied
     * by another.
     *
     * @param other The multiplier complex number.
     * @return The product of this complex number * another.
     */
    public ComplexNumber multiply(ComplexNumber other)
    {
        //declare new temp float newA equal to the calculation for muliplication for a
        float newA = this.a * other.a - this.b * other.b;
        //declare new temp float newB equal to the calculation for muliplication for b
        float newB = this.b * other.a + this.a * other.b;
        //return the new complex number respresenting the product of this and other
        return new ComplexNumber(newA, newB);
    }

    /**
     * Returns the result of this complex number divided by
     * another.
     *
     * @param other The divisor complex number.
     * @return The quotient of this complex number divided by another.
     * @throws ArithmeticException You cannot divide by zero if the divisor
     * equates to 0.
     */
    public ComplexNumber divide(ComplexNumber other)
    {
        //if statement to check if the divisor is 0
        if ((other.a * other.a + other.b * other.b) == 0)
        {
            //if the divisor is 0, throws new Arithmetic Exception "Cant divide by zero"
            throw new ArithmeticException("You cannot divide by zero.");
        }
        //else the divisor does not equal 0
        else
        {
            //declare new temp float newA equal to the calculation of a for division
            float newA = (this.a * other.a + this.b * other.b)/(other.a * other.a + other.b * other.b);
            //declare new temp float newB equal to the calculation of b for division
            float newB = (this.b * other.a - this.a * other.b)/(other.a * other.a + other.b * other.b);
            //return the new Complex Number which represents the quotient of this and other
            return new ComplexNumber(newA, newB);
        }
    }
    /**
     * Returns the value of the real part of this instance
     * of ComplexNumber.
     * @return This real part.
     */
    public float getA()
    {
        return this.a;
    }

    /**
     * Returns the value of the imaginary part of this instance
     * of ComplexNumber.
     * @return This imaginary part.
     */
    public float getB()
    {
        return this.b;
    }


    /**
     * Returns true if the Object other is an instance
     * of ComplexNumber and does not equal null
     * and has real parts equal to it's imaginary parts.
     * Returns false if Object other is null.
     *
     * @return A boolean value depending on the value of other.
     * @param object The object.
     */
    @Override
    public boolean equals(Object object)
    {
        //if the object is not an instance of ComplexNumber return false (null filtered)
        if (!(object instanceof ComplexNumber))
        {
            return false;
        }
        //else the object is an instance of ComplexNumber return whether its values are equal to ours.
        else
        {
            //cast another object equal to an intance of Complex Number
            ComplexNumber other = (ComplexNumber)object;
            //return whether these values are the same as other values
            return (other.a == this.a && other.b == other.b);
        }
    }

    /**
     * Returns the formatted result of
     * complex number.
     *
     * @return A formatted string of elements a and b.
     */
    @Override
    public String toString()
    {
        return this.a + " + " + this.b + "i";
    }
}