/**
 * Class RealNumber allows for manipulating
 * and checking the real part of a complex
 * number.
 *
 * @author Michael Rogers
 */
public class RealNumber extends ComplexNumber
{
    /**
     * Constructs a new instance of real number
     * from the superclass ComplexNumber.
     *
     * @param a The real part of a number.
     */
    public RealNumber(float a)
    {
        //call to the superclass initializing the variables for the subclass
        super(a, 0.0f);
    }
    /**
     * Returns false if this instance of a is greater than
     * or equal to other a.
     * Returns true if this instance of a is less than
     * other a.
     * @param other The other value of a real number.
     * @return A boolean value dependent on other.
     */
    public boolean isLessThan(RealNumber other)
    {
        //if this a is less than another a return true
        if (this.a < other.a)
        {
            //return true
            return true;
        }
        // else this a is greater than or equal to another a return false
        else
        {
            //return false
            return false;
        }
    }

    /**
     * Returns true if this instance of a is greater than
     * other a.
     *
     * Returns false if this instance of a is less than
     * or equal to other a.
     * @param other Another value of a.
     * @return A boolean value dependent on other.
     */
    public boolean isGreaterThan(RealNumber other)
    {
        //if this a is greater than other a return true
        if (this.a > other.a)
        {
            //return true
            return true;
        }
        //else this a is less than or equal to other a return false
        else
        {
            //return false
            return false;
        }
    }

    /**
     * Returns a real number
     *
     * @return Formatted string of real number a.
     */
    @Override
    public String toString()
    {
        return String.format("%.2f", this.a);
    }
}