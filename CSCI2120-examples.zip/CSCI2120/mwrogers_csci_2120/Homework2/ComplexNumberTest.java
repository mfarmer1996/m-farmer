import org.junit.Before;
import java.util.Random;
import org.junit.Test;
import org.junit.*;
import static org.junit.Assert.*;

/**
 * @author Michael Rogers
 * @date: 5/1/2017
 */

public class ComplexNumberTest{
    /**
     * Variable declaration.
     */
    private ComplexNumber someNumber;
    private ComplexNumber complexZero;
    private Object object;
    private static ComplexNumber cn, cn1, cn2, cn3, cn4, cn5, cn6, cn7, cn8, cn9;
    public static final float EPSILON = 0.0000001f;

    /**
     * Initializes variables.
     */
    @Before
    public void initialize(){
        Random random = new Random();
        complexZero = new ComplexNumber(0.0f, 0.0f);
        someNumber = new ComplexNumber(random.nextFloat(), random.nextFloat());
        cn = new ComplexNumber(1.0f,1.0f);
        cn1 = new ComplexNumber(1.0f,0.0f);
        cn2 = new ComplexNumber(-1.0f,0.0f);
        cn3 = new ComplexNumber(0.0f,1.0f);
        cn4 = new ComplexNumber(0.5f,0.0f);
        cn5 = new ComplexNumber(1.0f,1.0f);
        cn6 = new ComplexNumber(-1.0f,-1.0f);
        cn7 = new ComplexNumber(2.0f,0.0f);
        cn8 = new ComplexNumber(0.0f,2.0f);
        cn9 = new ComplexNumber(22.0f,-4.0f);

    }

    /**
     * Test that the ComplexNumbers entered are equal within the boundaries
     * of our defined value EPSILON.
     * @param actual the ComplexNumber.
     * @param expected what the ComplexNumber should be.
     */
    private static void assertEqual(final ComplexNumber actual, final ComplexNumber expected){
        assertEquals(actual.getA(), expected.getA(), EPSILON);
        assertEquals(actual.getB(), expected.getB(), EPSILON);
    }

    /**
     * Test that the add() method is working properly.
     */
    @Test
    public void testAdd(){
        assertEqual(cn.add(cn1),new ComplexNumber(2.0f,1.0f));
        assertEqual(cn.add(cn9), new ComplexNumber(23.0f,-3.0f));
        assertEqual(cn5.add(cn7), new ComplexNumber(3.0f,1.0f));

    }


    /**
     * Test that the subtract() method is working properly.
     */
    @Test
    public void testSubtract(){
        assertEqual(cn8.subtract(cn3), new ComplexNumber(0.0f,1.0f));
        assertEqual(cn7.subtract(cn2), new ComplexNumber(3.0f,0.0f));
        assertEqual(cn5.subtract(cn4), new ComplexNumber(0.5f,1.0f));
    }

    /**
     * Test that the multyiply() method is working properly.
     */
    @Test
    public void testMultiply(){
        assertEqual(cn6.multiply(cn8), new ComplexNumber(2.0f,-2.0f));
        assertEqual(cn3.multiply(cn3), new ComplexNumber(-1.0f,0.0f));
        assertEqual(cn7.multiply(cn2), new ComplexNumber(-2.0f,0.0f));
    }

    @Test
    public void testDivide(){
        assertEqual(cn6.divide(cn8), new ComplexNumber(-0.5f,0.5f));
        assertEqual(cn3.divide(cn2), new ComplexNumber(0.0f,-1.0f));
        assertEqual(cn1.divide(cn8), new ComplexNumber(0.0f,-0.5f));

    }
    /**
     * Tests that the getA() method is working properly.
     */
    @Test
    public void testGetA(){
        assertEquals(cn.getA(),1.0f,EPSILON);
        assertEquals(someNumber.getA(),someNumber.getA(),EPSILON);
        assertEquals(cn1.getA(),1.0f, EPSILON);


    }

    /**
     * Tests that the getB() method works as intended.
     */
    @Test
    public void testGetB(){
        assertEquals(0.0f,cn4.getB(),EPSILON);
        assertEquals(-1.0f,cn6.getB(),EPSILON);
        assertEquals(-4.0f,cn9.getB(),EPSILON);



    }

    /**
     * Test that a Complex Number added by zero returns the same value.
     */
    @Test
    public void addingZeroShouldNotChangeValue(){
        assertTrue(someNumber.add(complexZero).equals(someNumber));
    }

    /**
     * Test that a Complex Number subtracted by 0 returns the same value.
     */
    @Test
    public void subtractingZeroShouldNotChangeValue(){assertTrue(someNumber.subtract(complexZero).equals(someNumber));
    }


    /**
     * Test that a Complex Number multiplied by 0 is 0.
     */
    @Test
    public void multiplyingByZeroShouldReturnZero(){assertTrue(someNumber.multiply(complexZero).equals(complexZero));
    }


    /**
     * Test that a Complex Number divided by zero throws ArithmeticException.
     * @throws ArithmeticException e
     */
    @Test(expected=ArithmeticException.class)
    public void dividingByZeroShouldThrowException(){
        someNumber.divide(complexZero);
    }


    /**
     * Test that the equals() method is working as intended.
     */
    @Test
    public void testEquals(){
        assertFalse(cn.equals(object));
        assertTrue(cn.equals(cn));
        assertTrue(cn1.equals(cn1));
        assertTrue(cn2.equals(cn2));
        assertTrue(cn3.equals(cn3));
        assertTrue(cn4.equals(new ComplexNumber(0.5f,0.0f)));
    }

    /**
     * Test that the toString method is working as intended.
     */
    @Test
    public void testToString()
    {
        assertEquals("1.0 + 1.0i", cn.toString());
        assertEquals("22.0 + -4.0i", cn9.toString());
        assertEquals("0.0 + 0.0i", complexZero.toString());
    }

}
