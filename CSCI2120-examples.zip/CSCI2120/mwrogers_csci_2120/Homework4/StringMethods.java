import java.util.*;
/**
 * The main part of HW4. Implement both of these methods.
 */
public class StringMethods {

    /** No reason to instantiate this class, so the constructor is private. */
    private StringMethods(){ }

    /*
     * TODO: Fill in the areEqual and isPalindrome methods below with recursive implementations.
     *
     * These methods are recursive, so they either solve the problem right away (the base case),
     * or reduce the input to a simpler problem before calling themselves again (the recursive case).
     */

    ///////////////////////////////////////////////////////////
    // PART ONE
    ///////////////////////////////////////////////////////////

    /**
     * Returns whether two NCStrings are equal. The comparison respects case (so 'test' != 'Test').
     *
     * @return Whether two NCStrings are equal.
     */
    public static boolean areEqual(final NCString a, final NCString b){
        //If both NCStrings are empty
        if (a.getLength() == 0 && b.getLength() == 0){
            //Return true they are equal
            return true;
        }
        //Else if both NCStrings have a length of 1 and have equal characters at the first index
        else if (a.getLength() == 1 && b.getLength() == 1 && a.getFirstChar() == b.getFirstChar()){
            //Return true they are equal
            return true;
        }
        //Else if both NCStrings have a length of 2 and have equal first and last chars
        else if (a.getLength() == 2 && b.getLength() == 2 && a.getFirstChar() == b.getFirstChar() && a.getLastChar()
                == b.getLastChar()){
            //Return true
            return true;
        }
        //Else if both NCStrings are greater than or equal to 3 chars and have equal first and last chars
        else if (a.getLength() >= 3 && b.getLength() >= 3 && a.getFirstChar() == b.getFirstChar() && a.getLastChar()
                == b.getLastChar()){
            //Return the middle characters of both NCStrings to recurse through the method again
            return areEqual(a.getMiddleChars(), b.getMiddleChars());
        }
        //Else the NCStrings are not any of these
        else{
            //Return false they are not equal
            return false;
        }
    }

    ///////////////////////////////////////////////////////////
    // PART TWO
    ///////////////////////////////////////////////////////////

    /**
     * Returns whether two NCStrings are palindromes. A String is a palindrome if it reads the
     * same forwards and backwards, respecting case and whitespace. E.g.:
     *
     * "racecar"
     * "level"
     * "a"
     * "aa"
     * "mom"
     * "radar radar"
     * ""           <-- the empty string.
     *
     * The following would not be considered palindromes:
     *
     * "example"
     * "top spot"   <-- because of the space
     * "Mom"        <-- because of the capitalization
     *
     * @param s The NCString to examine. Can be assumed to be non-null.
     * @return Whether the argument is a palindrome, as defined above.
     */
    public static boolean isPalindrome(final NCString s){
        //If the NCString s is whitespace or 1 value
        if(s.getLength() == 0 || s.getLength() == 1){
            //Return true it is a palindrome
            return true;
        }
        //Else if the NCString has a length of 2 or more and the first character is equal to the last character
        else if (s.getFirstChar() == s.getLastChar()){
            //Return the middle characters of the NCString to recurse through the method again
            return isPalindrome(s.getMiddleChars());
       }
       //Else the NCString is not any of these
       else {
            //Return false it is not a palindrome
            return false;
        }

    }
}
