import java.util.ArrayList;
import static org.apache.commons.lang3.text.WordUtils.*;

/**
 * A class that models a list of grocery items.
 *
 * Hint: Use ArrayList to do all the heavy lifting for storing your items.
 */

public class GroceryList implements java.io.Serializable {
    //Declare instance variable grocery to hold an ArrayList of Strings.
    private ArrayList<String> grocery;
    //
    /**
     * Constructs a new GroceryList object that is initially empty.
     */
    public GroceryList() {
        grocery = new ArrayList<String>();
    }

    /**
     * Returns the number of items currently in the grocery list.
     *
     * @return The number of items in the list.
     */
    public int getItemCount() {
        return grocery.size();
    }

    /**
     * If the given item String is not in the list yet (ignoring capitalization
     * and leading/trailing whitespace), appends the item to the end
     * of the list. Otherwise, does nothing. A GroceryList should be able
     * to hold as many unique item names as the user desires. If the item
     * contains no actual text other than whitespace, this should not be added.
     *
     * @param item The item to add.
     */
    public void addItem(final String item) {
        //If the canonical form of the item passed is not on a grocery list and is not White Space.
        if (!(grocery.contains(capitalizeFully(item).trim())) && !(item.isEmpty())) {
            //Add the item to a grocery list.
            grocery.add(item);
        }
        //Else do nothing.
        else {
            return;
        }
    }

    /**
     * Removes the item at the specified index. If the index specified is
     * >= this.getItemCount(), an IllegalArgumentException should be thrown.
     * After removal of an item, the index of all items past the specified index
     * should be decremented. E.g.:
     * <p>
     * Before:
     * 0 => Eggs
     * 1 => Milk
     * 2 => Spinach
     * <p>
     * list.removeItemAtIndex(1);
     * <p>
     * After:
     * 0 => Eggs
     * 1 => Spinach
     *
     * @param index The index (zero-based) to remove.
     * @throws IllegalArgumentException index is out of bounds
     */
    public void removeItemAtIndex(final int index) {
        //If the index specified is less than, greater than, or equal to the size of the Array.
        if (index >= this.getItemCount() || index < 0) {
            //Throw an illegal ArgumentException indicating that the index specified is out of bounds to the user.
            throw new IllegalArgumentException("The index specified is out of bounds.");
        }
        //Else the index specified is within the bounds of our array.
        else {
            //Remove the item located at that index.
            grocery.remove(index);
        }
    }

    /**
     * Returns the item String at the specified index. If the index specified
     * is >= this.getItemCount(), an IllegalArgumentException should be thrown. The
     * String returned should be given in "canonical" form", that is, with no leading/trailing
     * whitespace and the first letter of each individual word capitalized, regardless of
     * how the item was added initially. E.g.:
     * <p>
     * "eggs" => "Eggs"
     * "toilet paper" => "Toilet Paper"
     * "MILK" => "Milk"
     * "  coffee " => "Coffee"
     *
     * @param index The index (zero-based) to fetch.
     * @return The grocery item text at the given index, in the canonical form specified above.
     * @throws IllegalArgumentException index is out of bounds
     */
    public String getItemAtIndex(final int index) {
        //Declare a variable to hold the value of item.
        String item;
        //If the index specified is less than, greater than, or equal to the size of the Array.
        if (index >= this.getItemCount() || index < 0) {
            //Throw an illegal ArgumentException indicating that the index specified is out of bounds to the user.
            throw new IllegalArgumentException("The index specified is out of bounds.");
        }
        //Else the index specified is within the bounds of our array.
        else {
            //Set item equal to the value of the String at the index specified.
            item = grocery.get(index);
            //Set item equal to it's conical form.
            item = (capitalizeFully(item)).trim();
        }
        //Return item.
        return item;
    }

    /**
     * @{inheritDoc} Returns a String representation of this list. Should use the StringBuilder class to build
     * up the result. A representation of a GroceryList is a human-readable series of lines with
     * a line number (1-based), followed by a period and space (". "), followed by the item. There
     * should be no trailing newline. If the list is empty, the words "(Empty List)" should be returned.
     * <p>
     * E.g. for GroceryList {0 => "Eggs", 1 => "Bacon", 2 => "Bread"}, it should return:
     * <p>
     * "1. Eggs
     * 2. Bacon
     * 3. Bread"
     */
    @Override
    public String toString() {
        //Declare a variable and initialize it to 0 to
        //respresent the number of items on a grocery list.
        int numberOfItems = 0;
        //Create a new StringBuilder object and initialize it to null.
        StringBuilder sb = new StringBuilder();
        //For each item on a grocery list.
        for (String item : grocery) {
            //Increment the number of Items by 1.
            numberOfItems++;
            //Append the number of the item followed by . and the item in canonical form.
            sb.append(numberOfItems).append(". ").append(capitalizeFully(item).trim());
            //If the index of the current item is not the last item in the grocery list.
            if (!(grocery.indexOf(item) == this.getItemCount()-1)){
                //Append a new line.
                sb.append("\n");
            }
        }
        //If the resulting list is empty.
        if (sb.toString().isEmpty()) {
            //Return (Empty List).
            return "(Empty List)";
        }
        //Else return the grocery list.
        else {
            return sb.toString();
        }
    }
}


