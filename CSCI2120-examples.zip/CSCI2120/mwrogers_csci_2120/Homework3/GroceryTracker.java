import java.io.*;
import java.util.*;
import java.nio.*;
public class GroceryTracker {
    //
    private static GroceryList currentList = new GroceryList();
    //Streams for serialization.
    private static ObjectOutputStream serializationOutput = null;
    private static ObjectInputStream deserializationInput = null;
    //File implementation.

    public static void main(String[] args) {
        //Load args.
        openInputStream(args[0]);
        File file = new File(args[0]);
        //Loop ui.
        while(true){
            //Print User Interface.
            System.out.print("Welcome to GroceryTracker!\nCurrent File: <" +
                    file.getAbsolutePath() + ">\nPlease select an option:\n" +
                    "  1) View List\n  2) Add An Item\n  3) Remove An Item\n  4) Save\n  5) Quit\n Choice:" +
                    "\t");

            //Get user input.
            Scanner scanner = new Scanner(System.in);
            int input = scanner.nextInt();

            if (input == 1) {
                //View a listing of the file loaded.
                System.out.println(currentList.toString());
            } else if (input == 2) {
                //Prompt the user to enter a new item.
                System.out.println("Please enter the item you wish to add.");
                //Add an item the current list.
                String item = scanner.next();
                currentList.addItem(item);
            } else if (input == 3) {
                //Prompt user for index to remove.
                System.out.println("Please enter the index of the item you wish to remove.");

                //Remove an item from the current list.
                int index = scanner.nextInt();
                currentList.removeItemAtIndex((index - 1));
            } else if (input == 4) {
                //Save the current list to file.
                openOutputStream(args[0]);
                writeObjects();
                closeOutputStream();
                //Print to the user file is saved.
                System.out.println("File saved successfully.");
            }
            else if (input == 5) {
                System.out.println("Would you like to save your changes?\n" +
                        "[Y]es\n" +
                        "[N]o");
                String yesOrNo = scanner.next();
                if (yesOrNo.equalsIgnoreCase("y")) {
                    //Save the current list to file and exit the program.
                    openOutputStream(args[0]);
                    writeObjects();
                    closeOutputStream();
                    System.out.println("File saved successfully.");
                    System.exit(1);
                } else if (yesOrNo.equalsIgnoreCase("n")) {
                    //Exit the program
                    System.exit(1);
                }
            }
        }
    }
    /**
     * Opens an ObjectOutputStream to serialize the contents
     * of the Grocery List.
     */
    public static void openOutputStream(String file) {
        try {
            serializationOutput = new ObjectOutputStream(new FileOutputStream(file));
        } catch (IOException e) {
            System.out.println("Error opening file for serialization.");
            System.exit(1); //Terminate program and signal error to OS
        }
    }
    public static void writeObjects(){
        try{
            serializationOutput.writeObject(currentList);

        }
        catch (IOException e){
            System.out.println("Error writing Object to file.");
            System.exit(1); //Terminate program and signal error to OS
        }
        catch(NullPointerException e){
            System.out.println("OutputStream not previously opened.");
            System.exit(1); //Terminate program and signal error to OS
        }
    }

    /**
     * Closes an ObjectOutputStream.
     *
     * @throws IOException e, NullPointerException e.
     */
    public static void closeOutputStream() {
        try{
            serializationOutput.close();
        }
        catch (IOException e){
            System.out.println("Error closing file.");
        }
        catch(NullPointerException e) {
            System.out.println("OutputStream not previously opened.");
            System.exit(1); //Terminate program and signal error to OS
        }
    } // end method closeOutputStream

    /**
     *Opens a new InputStream.
     *
     * @throws IOException e.
     */
    public static void openInputStream(String file){
        try{
            deserializationInput = new ObjectInputStream(new FileInputStream(file));

            currentList = (GroceryList) deserializationInput.readObject();
            deserializationInput.close();
        }
        catch (IOException e){

            System.out.println("Error opening deserialization file.");

            //System.exit(1); //Terminate program and report OS
        }
        catch(NullPointerException e) {
            System.out.println("InputStream not previously opened.");
            System.exit(1); //Terminate program and report OS
        }
        catch (ClassNotFoundException e){
            System.out.println("Object type invalid.");
            System.exit(1); //Terminate program and report OS
        }
    } // end method openInputStream
}