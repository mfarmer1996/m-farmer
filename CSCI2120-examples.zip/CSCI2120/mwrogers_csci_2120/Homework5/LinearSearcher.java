
import java.util.*; //import list and comparator libraries
/**
 * Holds methods to search a generic list of objects using LINEAR SEARCH.
 * @author: Michael Rogers
 * @date: 4/4/17
 */
public class LinearSearcher implements Searcher{
    /**
     *Searches a list for the given key using Linear Search method.
     * @param data The data to search across. Assumed to have been previously sorted.
     * @param key The value to search for.
     * @param <E> the type of elements stored int he list. Must implement
     *           Comparable.
     * @return An array, a, containing exactly two elements:
     *              a[0] = the search result index defined above.
     *              a[1] = the number of times the algorithm called either
     *              .equals(), .compareTo() or .compare().
     */
    public <E extends Comparable <E>> int[] search(List<? extends E> data, E key){
        Comparator<E> comparator = new DefaultComparator<E>();
        return search(data, key, comparator);
    }

    /**
     * Searches a list for the given key using Linear Search method.
     * @param data The data to search across, assumed to be sorted.
     * @param key The value to search for.
     * @param comparator The comparator to use for ordering the elements.
     * @param <E>
     * @return An array, a, containing exactly two elements:
     *              a[0] = the search result index defined above.
     *              a[1] = the number of times the algorithm called either
     *              .equals(), .compareTo() or .compare().
     */
    public <E> int[] search(List<? extends E> data, E key, Comparator <E> comparator){
        int count = 0;
            for(int i = 0; i< data.size(); i++){
                count++;
                if(comparator.compare(data.get(i),key) == 0){
                    return new int[]{i,count};
                }
            }
            return new int[]{-1,count};
        }
}
