/**
 *
 */
import java.util.*;

/**
 * Sorts a generic list of objects sing INSERTION SORT.
 *
 * @author: Michael Rogers
 * @date: 4/30/17
 */
public class InsertionSorter implements Sorter{
    /**
     * Sorts the given data list using INSERTION SORT.
     * @param data The data to sort.
     * @param <E> The type of elements stored in the list. Must implement Comparable.
     * @return The number of times the search algorithm called .equals(), .compareTo(),
     * or .compare().
     */
    public <E extends Comparable<E>> int sort(List<E> data){
        int count = 0;
        E temp;
        for(int i = 1;i<data.size();i++){
            for(int j = 0; j<i;j++){
                if(data.get(i).compareTo(data.get(j)) < 0){
                    temp = data.get(j);
                    data.set(j,data.get(i));
                    data.set(i,temp);
                }
                else if(data.get(i).compareTo(data.get(j)) == 0){
                    temp = data.get(j+1);
                    data.set(j+1,data.get(i));
                    data.set(i,temp);
                }
                count++;
            }
        }
        return count;
    }

    /**
     * Performs same sort as above but using a custom comparator.
     * @param data The data to sort.
     * @param comparator The ordering to use.
     * @param <E> The type of elements stored in the list.
     * @return The number of times the search algorithm called .equals(), .compareTo(),
     * or .compare().
     */
    public <E> int sort(List<E> data, Comparator<E> comparator){
        int count = 0;
        E temp;
        for(int i = 1;i<data.size();i++){
            for(int j = 0; j<i;j++){
                if(comparator.compare(data.get(i),data.get(j)) < 0){
                    temp = data.get(j);
                    data.set(j,data.get(i));
                    data.set(i,temp);
                }
                else if(comparator.compare(data.get(i),data.get(j)) == 0){
                    temp = data.get(j+1);
                    data.set(j+1,data.get(i));
                    data.set(i,temp);
                }
                count++;
            }
        }
        return count;
    }


}