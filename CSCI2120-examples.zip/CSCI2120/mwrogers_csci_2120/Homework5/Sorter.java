/**
 * Interface Sorter which houses methods to sort an object.
 * @author: Michael Rogers
 * @date: 4/4/17
 */

import java.util.List;
import java.util.Comparator;
public interface Sorter{
    /**
     * Sorts the given data list, replacing the data in sorted values according to
     * their natural ordering. That is, {@literal i > j ==> data.get(i) >= data.get(j)}.
     * @param data The data to sort.
     * @param <E> The type of elements stored in the list. Must implement Comparable.
     * @return The number of times the search algorithm called .equals(), .compareTo(),
     * or .compare().
     */
     <E extends Comparable <E>> int sort(List<E> data);

    /**
     * Performs same sort as above but using custom comparator.
     * @param data The data to sort.
     * @param comparator The ordering to use.
     * @param <E> The type of elements stored in the list.
     * @return The number of times the search algorithm called .equals(), .compareTo(),
     * or .compare().
     */
    <E> int sort(List<E> data, Comparator <E> comparator);
}
