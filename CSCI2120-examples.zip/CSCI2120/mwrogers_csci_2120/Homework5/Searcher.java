
import java.util.List; //list
import java.util.Comparator; //comparator
/**
 * Interface Searcher which houses methods to search within an object.
 * @author: Michael Rogers
 * @date: 4/4/17
 */
public interface Searcher{
    /**
     *Searches a list for the given key. Returns any index, i, in the
     * List where data.get(i).equals(key), or -1 if no such
     * element exists. The data in the list is assumed to be in sorted
     * order according to their natural ordering. Assume that if
     * a.comparteTo(b) == 0, then a.equals(b).
     * @param data The data to search across. Assumed to have been previously sorted.
     * @param key The value to search for.
     * @param <E> the type of elements stored int he list. Must implement
     *           Comparable.
     * @return An array, a, containing exactly two elements:
     *              a[0] = the search result index defined above.
     *              a[1] = the number of times the algorithm called either
     *              .equals(), .compareTo() or .compare().
     */
    <E extends Comparable <E>> int[] search(List<? extends E> data, E key);

    /**
     * Performs the same search above with a custom Comparator that the input is assumed
     * to be in. Assume that if comparator.compare(a,b) == 0 then a.equals(b).
     * @param data The data to search across, assumed to be sorted.
     * @param key The value to search for.
     * @param comparator The comparator to use for ordering the elements.
     * @param <E> the type of elements stored in the list.
     * @return An array, a, containing exactly two elements:
     *              a[0] = the search result index defined above.
     *              a[1] = the number of times the algorithm called either
     *              .equals(), .compareTo() or .compare().
     */
    <E> int[] search(List<? extends E> data, E key, Comparator <E> comparator);
}
