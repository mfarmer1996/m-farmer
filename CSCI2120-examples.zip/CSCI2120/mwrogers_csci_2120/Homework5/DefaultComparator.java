import java.util.*;

/**
 * A custom comparator which compares objects of any type.
 * @param <E> The type of element we are comparing.
 */
public class DefaultComparator<E extends Comparable<E>> implements Comparator<E>{
    @Override
    public int compare(E x, E y){
        return x.compareTo(y);
    }
}