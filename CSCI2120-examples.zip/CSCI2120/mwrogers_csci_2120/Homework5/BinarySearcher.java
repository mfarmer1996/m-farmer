/**
 * Searches a list for a value using BinarySearch METHOD.
 */
import java.util.*;

/**
 * BinarySearcher class implements Searcer methods and defines them accordingly to
 * the Binary Search algorithm for generic objects.
 * @author: Michael Rogers
 * @date: 4/4/17
 */
public class BinarySearcher implements Searcher{
    /**
     *Searches a list for the given key using Binary Search method.
     * @param data The data to search across. Assumed to have been previously sorted.
     * @param key The value to search for.
     * @param <E> the type of elements stored int he list. Must implement
     *           Comparable.
     * @return An array, a, containing exactly two elements:
     *              a[0] = the search result index defined above.
     *              a[1] = the number of times the algorithm called either
     *              .equals(), .compareTo() or .compare().
     */
    public <E extends Comparable<E>> int[] search(List<? extends E> data, E key){
        return search(data,key,new DefaultComparator<E>());
    }

    /**
     * Searches a list for the given key using Binary Search method.
     * @param data The data to search across, assumed to be sorted.
     * @param key The value to search for.
     * @param comparator The comparator to use for ordering the elements.
     * @param <E>
     * @return An array, a, containing exactly two elements:
     *              a[0] = the search result index defined above.
     *              a[1] = the number of times the algorithm called either
     *              .equals(), .compareTo() or .compare().
     */
    public <E> int[] search(List<? extends E> data, E key, Comparator <E> comparator){
        int low = 0;
        int high = data.size() - 1;
        int index = (low + high +1)/2;
        int count = 0;
        while (low <= high){
            count++;
            final int comparison = comparator.compare(key,data.get(index));
            if(comparison == 0){
                return new int[]{index,count};
            }
            else if(comparison<0){
                high = index - 1;
            }
            else if(comparison>0){
                low = index + 1;
            }
            index = (low + high +1)/2;
        }
        return new int[]{-1,count};
    }


}