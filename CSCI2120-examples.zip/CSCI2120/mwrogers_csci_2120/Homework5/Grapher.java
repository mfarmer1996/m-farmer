import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.*;

/**
 * Generates a list of random integers which can be sorted based on the order specified.
 * Then prints the lists
 *
 * @author: Michael Rogers
 * @date: 4/30/2017
 *
 */
public class Grapher{


    public enum Order { RANDOM, ORDERED, REVERSED }
    private static final SecureRandom random = new SecureRandom();

    /**
     * Generates a list based on the order specified. ie. RANDOM, ORDERED, REVERSED
     * @param size the size of the list.
     * @param order the order of the list.
     * @return An ArrayList in the specified order.
     */
    public static List<Integer> makeList(final int size, final Order order){
        final List<Integer> result = new ArrayList<>();
        for (int i = 0; i < size; i++){
            result.add(random.nextInt(size*10));
        }
        switch (order){
            case RANDOM:
               break;
            case ORDERED:
                Collections.sort(result);
                break;
            case REVERSED:
                Collections.sort(result,Collections.reverseOrder());
        }
        return result;
    }

    /**
     * Instantiates a set of lists and to be searched and sorted, instantiates
     * a set of searchers and sorters and
     * then prints the amount of times each algorithm had to perform an
     * operation to search or sort a list.
     * @param args the arguments.
     */
    public static void main(String[] args){

        /* the key to search for*/
        final int KEY = 999;

        /*generate and instantiate lists for size n = 10,20,50,100,1000*/
        List<Integer> listOrd = Grapher.makeList(10,Order.ORDERED);
        List<Integer> listOrd1 = Grapher.makeList(20,Order.ORDERED);
        List<Integer> listOrd2 = Grapher.makeList(50,Order.ORDERED);
        List<Integer> listOrd3 = Grapher.makeList(100,Order.ORDERED);
        List<Integer> listOrd4 = Grapher.makeList(1000,Order.ORDERED);

        List<Integer> listRev = Grapher.makeList(10,Order.REVERSED);
        List<Integer> listRev1 = Grapher.makeList(20,Order.REVERSED);
        List<Integer> listRev2 = Grapher.makeList(50,Order.REVERSED);
        List<Integer> listRev3 = Grapher.makeList(100,Order.REVERSED);
        List<Integer> listRev4 = Grapher.makeList(1000,Order.REVERSED);

        List<Integer> listRand = Grapher.makeList(10,Order.RANDOM);
        List<Integer> listRand1 = Grapher.makeList(20,Order.RANDOM);
        List<Integer> listRand2 = Grapher.makeList(50,Order.RANDOM);
        List<Integer> listRand3 = Grapher.makeList(100,Order.RANDOM);
        List<Integer> listRand4 = Grapher.makeList(1000,Order.RANDOM);

        /* instantiate searchers and sorters */
        BinarySearcher binarySearcher = new BinarySearcher();
        LinearSearcher linearSearcher = new LinearSearcher();
        MergeSorter mergeSorter = new MergeSorter();
        InsertionSorter insertionSorter = new InsertionSorter();
        SelectionSorter selectionSorter = new SelectionSorter();

        /* print the number of operations to size for each algorithm*/
        System.out.println("ORDERED:");
        System.out.println("MergeSorter:    " + mergeSorter.sort(listOrd)+" operations for size 10.");
        System.out.println("InsertionSorter:    " + insertionSorter.sort(listOrd)+" operations for size 10.");
        System.out.println("SelectionSorter:    " + selectionSorter.sort(listOrd)+" operations for size 10.");
        System.out.println();
        System.out.println("MergeSorter:    " + mergeSorter.sort(listOrd1)+" operations for size 20.");
        System.out.println("InsertionSorter:    " + insertionSorter.sort(listOrd1)+" operations for size 20.");
        System.out.println("SelectionSorter:    " + selectionSorter.sort(listOrd1)+" operations for size 20.");
        System.out.println();
        System.out.println("MergeSorter:    " + mergeSorter.sort(listOrd2)+" operations for size 50.");
        System.out.println("InsertionSorter:    " + insertionSorter.sort(listOrd2)+" operations for size 50.");
        System.out.println("SelectionSorter:    " + selectionSorter.sort(listOrd2)+" operations for size 50.");
        System.out.println();
        System.out.println("MergeSorter:    " + mergeSorter.sort(listOrd3)+" operations for size 100.");
        System.out.println("InsertionSorter:    " + insertionSorter.sort(listOrd3)+" operations for size 100.");
        System.out.println("SelectionSorter:    " + selectionSorter.sort(listOrd3)+" operations for size 100.");
        System.out.println();
        System.out.println("MergeSorter:    " + mergeSorter.sort(listOrd4)+" operations for size 1000.");
        System.out.println("InsertionSorter:    " + insertionSorter.sort(listOrd4)+" operations for size 1000.");
        System.out.println("SelectionSorter:    " + selectionSorter.sort(listOrd4)+" operations for size 1000.");
        System.out.println();
        System.out.println("REVERSED:");
        System.out.println("MergeSorter:    " + mergeSorter.sort(listRev)+" operations for size 10.");
        System.out.println("InsertionSorter:    " + insertionSorter.sort(listRev)+" operations for size 10.");
        System.out.println("SelectionSorter:    " + selectionSorter.sort(listRev)+" operations for size 10.");
        System.out.println();
        System.out.println("MergeSorter:    " + mergeSorter.sort(listRev1)+" operations for size 20.");
        System.out.println("InsertionSorter:    " + insertionSorter.sort(listRev1)+" operations for size 20.");
        System.out.println("SelectionSorter:    " + selectionSorter.sort(listRev1)+" operations for size 20.");
        System.out.println();
        System.out.println("MergeSorter:    " + mergeSorter.sort(listRev2)+" operations for size 50.");
        System.out.println("InsertionSorter:    " + insertionSorter.sort(listRev2)+" operations for size 50.");
        System.out.println("SelectionSorter:    " + selectionSorter.sort(listRev2)+" operations for size 50.");
        System.out.println();
        System.out.println("MergeSorter:    " + mergeSorter.sort(listRev3)+" operations for size 100.");
        System.out.println("InsertionSorter:    " + insertionSorter.sort(listRev3)+" operations for size 100.");
        System.out.println("SelectionSorter:    " + selectionSorter.sort(listRev3)+" operations for size 100.");
        System.out.println();
        System.out.println("MergeSorter:    " + mergeSorter.sort(listRev4)+" operations for size 1000.");
        System.out.println("InsertionSorter:    " + insertionSorter.sort(listRev4)+" operations for size 1000.");
        System.out.println("SelectionSorter:    " + selectionSorter.sort(listRev4)+" operations for size 1000.");
        System.out.println();
        System.out.println("RANDOM");
        System.out.println("MergeSorter:    " + mergeSorter.sort(listRand)+" operations for size 10.");
        System.out.println("InsertionSorter:    " + insertionSorter.sort(listOrd)+" operations for size 10.");
        System.out.println("SelectionSorter:    " + selectionSorter.sort(listOrd)+" operations for size 10.");
        System.out.println();
        System.out.println("MergeSorter:    " + mergeSorter.sort(listRand1)+" operations for size 20.");
        System.out.println("InsertionSorter:    " + insertionSorter.sort(listRand1)+" operations for size 20.");
        System.out.println("SelectionSorter:    " + selectionSorter.sort(listRand1)+" operations for size 20.");
        System.out.println();
        System.out.println("MergeSorter:    " + mergeSorter.sort(listRand2)+" operations for size 50.");
        System.out.println("InsertionSorter:    " + insertionSorter.sort(listRand2)+" operations for size 50.");
        System.out.println("SelectionSorter:    " + selectionSorter.sort(listRand2)+" operations for size 50.");
        System.out.println();
        System.out.println("MergeSorter:    " + mergeSorter.sort(listRand3)+" operations for size 100.");
        System.out.println("InsertionSorter:    " + insertionSorter.sort(listRand3)+" operations for size 100.");
        System.out.println("SelectionSorter:    " + selectionSorter.sort(listRand3)+" operations for size 100.");
        System.out.println();
        System.out.println("MergeSorter:    " + mergeSorter.sort(listRand4)+" operations for size 1000.");
        System.out.println("InsertionSorter:    " + insertionSorter.sort(listRand4)+" operations for size 1000.");
        System.out.println("SelectionSorter:    " + selectionSorter.sort(listRand4)+" operations for size 1000.");
        System.out.println();
        System.out.println();
        System.out.println("BinarySearcher:     " + Arrays.toString(binarySearcher.search(listOrd,KEY)) + " operations for size "+listOrd.size());
        System.out.println("LinearSearcher:     " + Arrays.toString(linearSearcher.search(listOrd,KEY)) + " operations for size "+listOrd.size());
        System.out.println();
        System.out.println("BinarySearcher:     " + Arrays.toString(binarySearcher.search(listOrd1,KEY)) + " operations for size "+listOrd1.size());
        System.out.println("LinearSearcher:     " + Arrays.toString(linearSearcher.search(listOrd1,KEY)) + " operations for size "+listOrd1.size());
        System.out.println();
        System.out.println("BinarySearcher:     " + Arrays.toString(binarySearcher.search(listOrd2,KEY)) + " operations for size "+listOrd2.size());
        System.out.println("LinearSearcher:     " + Arrays.toString(linearSearcher.search(listOrd2,KEY)) + " operations for size "+listOrd2.size());
        System.out.println();
        System.out.println("BinarySearcher:     " + Arrays.toString(binarySearcher.search(listOrd3,KEY)) + " operations for size "+listOrd3.size());
        System.out.println("LinearSearcher:     " + Arrays.toString(linearSearcher.search(listOrd3,KEY)) + " operations for size "+listOrd3.size());
        System.out.println();
        System.out.println("BinarySearcher:     " + Arrays.toString(binarySearcher.search(listOrd4,KEY)) + " operations for size "+listOrd4.size());
        System.out.println("LinearSearcher:     " + Arrays.toString(linearSearcher.search(listOrd4,KEY)) + " operations for size "+listOrd4.size());
        System.out.println();





    }

}