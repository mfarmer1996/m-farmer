import java.util.*;

/**
 * Sorts a list of generic objects using SELECTION SORT.
 *
 * @author: Michael Rogers
 * @date: 4/30/17
 */
public class SelectionSorter implements Sorter {

    /**
     * Sorts a list using SELECTION SORT.
     * @param data The data to sort.
     * @param <E> The type of elements stored in the list.
     * @return The number of times the search algorithm called .equals(), .compareTo(),
     * or .compare().
     */
    public <E extends Comparable<E>> int sort(List<E> data) {
        int count = 0;
        int smallestValue = 0;
        E temp;
        for (int i = 0; i < data.size(); i++) {
            smallestValue = i;
            for (int j = i; j < data.size(); j++) {
                if (data.get(smallestValue).compareTo(data.get(j)) > 0) {
                    smallestValue = j;
                }
                count++;
            }
            temp = data.get(smallestValue);
            data.set(smallestValue, data.get(i));
            data.set(i, temp);
        }
        return count;
    }

    /**
     * Performs same sort as above but using a custom comparator.
     * @param data The data to sort.
     * @param comparator The ordering to use.
     * @param <E> The type of elements stored in the list.
     * @return The number of times the search algorithm called .equals(), .compareTo(),
     * or .compare().
     */
    public <E> int sort(List<E> data, Comparator<E> comparator) {
        int count = 0;
        int smallestValue = 0;
        E temp;
        for (int i = 0; i < data.size(); i++) {
            smallestValue = i;
            for (int j = i; j < data.size(); j++) {
                if (comparator.compare(data.get(smallestValue), data.get(j)) > 0) {
                    smallestValue = j;
                }
                count++;
            }
            temp = data.get(smallestValue);
            data.set(smallestValue, data.get(i));
            data.set(i, temp);
        }
        return count;
    }
}


