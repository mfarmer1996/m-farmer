public class X<E extends Comparable<E>> implements Comparable<E>{
    public int sort<E extends Comparable<E>>(E a, E b){
        if(this.a.compareTo(this.b)>0){
            E c = this.a;
            this.a = this.b;
            this.b = c;

            return (a,b);
        }
    }
        }

