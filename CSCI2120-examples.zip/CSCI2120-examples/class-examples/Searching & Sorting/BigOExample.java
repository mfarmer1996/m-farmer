import java.util.List;

/**
 * Created by nathan on 2017-03-20.
 */
public class BigOExample {

    public void doSomething(int[] data){
        for (int i = 0; i < data.length; i++){
            for (int j = 0; j < data.length; j++) {
                System.out.println(data[i]);
                System.out.println(data[i]);
            }
        }
    }


}
