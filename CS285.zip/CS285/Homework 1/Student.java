/**
 *Models a Student object.
 *
 * @author: Michael Rogers
 * @studentID: M14004758
 * @class: CS 285
 * @date: 2017-09-09
 */
public class Student{
    /**
     * Student vars.
     */
    private String studentName;
    private String studentID;
    private int studentCredits;

    /**
     * Constructs a Student object.
     * @param studentName the name of a Student.
     * @param studentID the ID number of a Student.
     */
    public Student(String studentName, String studentID, int studentCredits){
        this.studentName = studentName;
        this.studentID = studentID;
        this.studentCredits = studentCredits;
    }

    /**
     * Returns the name of a student.
     * @param aStudent a Student.
     * @return studentName the name of Student a.
     */
    public String getStudentName(Student aStudent){
        return aStudent.studentName;
    }

    /**
     *Returns a student's ID.
     * @return studentID the student's ID.
     */
    public String getStudentID(){
        return this.studentID;
    }

    /**
     *Sets a students name.
     * @param studentName the student's name to be set.
     */
    public void setStudentName(String studentName){
        this.studentName = studentName;
    }

    /**
     * Adds credits to a Student.
     * @param numberOfCreditsToAdd credits to add.
     */
    public void addCredits(int numberOfCreditsToAdd){
        this.studentCredits += numberOfCreditsToAdd;
    }

    /**
     *
     * @param aStudent a student.
     * @return aStudent studentCredits.
     */
    public int getStudentCredits(Student aStudent){
        return aStudent.studentCredits;
    }


    /*
        Returns a formatted String of a Student.
     */
    @Override
    public String toString(){
        return this.studentName +", Student ID: " + this.studentID + ", Credits: " + this.studentCredits;
    }

}