import java.util.ArrayList; /* IMPORTS */
/**
 *Models an enrollment list of one Lab Class.
 * @author: Michael Rogers
 * @studentID: M14004758
 * @class: CS 285
 * @date: 2017-09-09
 */
public class LabClass{

    /**
     *LabClass vars.
     */
    private static final int MAX_CAPACITY = 5;
    private ArrayList<Student> classList;
    private int roomNumber;
    private String classDay;
    private String classTime;
    private String instructor;
    private int numberOfStudents;

    /**
     *
     * @param classList the ArrayList of object type Student in a LabClass.
     * @param roomNumber the room number of a LabClass.
     * @param classDay the day of a LabClass.
     * @param classTime the time of a LabClass.
     * @param instructor the Instructor of a LabClass.
     */
    public LabClass(ArrayList<Student> classList, int roomNumber, String classDay, String classTime, String instructor){
        this.classList = classList;
        this.roomNumber = roomNumber;
        this.classDay = classDay;
        this.classTime = classTime;
        this.instructor = instructor;
    }

    public void addStudent(Student aStudent){
        for(Student student : classList){
            if(student == aStudent){
                throw new IllegalArgumentException("You are trying to add the same student twice.");
            }
        }
        if(this.classList.size() < MAX_CAPACITY) {
            this.classList.add(aStudent);
        }
        else{
            throw new IllegalArgumentException("This class is full.");
        }

    }
    /**
     *Returns the number of students in a class.
     * @return numberOfStudents the number of students.
     */
    public int getNumberOfStudents(){
        return this.classList.size();
    }


    /**
     *Parses through each Student in a given LabClass and outputs
     * each individual toString.
     * @return studentDetails student details.
     */
    public String getStudents(){
        String studentDetails = "";
        for(Student aStudent : this.classList){
              studentDetails += aStudent.toString() + "\n";
        }
        return studentDetails;
    }

    /**
     *Sets the room number of a LabClass.
     * @param roomNumber the room number.
     */
    public void setRoomNumber(int roomNumber){
        this.roomNumber = roomNumber;
    }

    /**
     *Sets the time of a LabClass.
     * @param classTime the time to be set.
     */
    public void setTime(String classDay, String classTime){
        this.classDay = classDay;
        this.classTime = classTime;
    }

    /**
     * Sets the name of the Instructor for this LabClass.
     * @param instructor the name of the Instructor.
     */
    public void setInstructor(String instructor){
        this.instructor = instructor;
    }

    /**
     *Returns all of the details of a LabClass.
     * @return The details of this LabClass.
     */
    @Override
    public String toString(){

        return "Lab class " + this.classDay + ", " + this.classTime + "." + "\n" +
                "Instructor: " + this.instructor + "\n" +
                "Class list: \n" +
                this.getStudents() +
                "Number of Students: " + this.getNumberOfStudents();
        }

    }
