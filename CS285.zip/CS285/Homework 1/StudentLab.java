

import java.util.ArrayList; /* IMPORTS */
/**
 *Models the interaction between a Student and their LabClass.
 * @author: Michael Rogers
 * @studentID: M14004758
 * @class: CS 285
 * @date: 2017-09-09
 */
public class StudentLab{
    public static void main(String []x){
        /**
         * Instantiating 3 new Student Objects.
         */
        Student a = new Student("Jerald Jeraldson", "M1400001", 30);
        Student b = new Student("Rachel Rachelson", "M1400002",20);
        Student c = new Student("Jack Jackson", "M1400003", 60);

        /**
         * Constructing a new LabClass.
         */
        LabClass CS285 = new LabClass(new ArrayList<Student>(), 212, "T-TH", "12:30 PM - 1:45 PM", "Izadoost");

        /**
         * Enrolling the 3 Students into the LabClass.
         */
        CS285.addStudent(a);
        CS285.addStudent(b);
        CS285.addStudent(c);

        /**
         * Adding 3 Credits to each Student.
         */
        a.addCredits(3);
        b.addCredits(3);
        c.addCredits(3);

        /**
         * Store the toString for CS285 LabClass and print.
         */
        String s = CS285.toString();
        System.out.println(s);
    }

}