interface IObserver
    {
        void update(int i);
    }