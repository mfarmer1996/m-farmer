
interface ITeacher
{
public String getDetails();
}