public abstract class ComponentDecorator extends Computer{
	public abstract String description();
}