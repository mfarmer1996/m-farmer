public class Monitor extends ComponentDecorator{
	Computer computer;
	public Monitor(Computer computer)
	{
		this.computer=computer;
	}
	public String description(){
		String s=computer.description() + " and a Monitor too";
		return s;
	}
}