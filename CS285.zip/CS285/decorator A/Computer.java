public class Computer
{
	public Computer()
	{
	}
	public String description()
	{
	String s="You have a Computer";
	return s;
	
	}
}