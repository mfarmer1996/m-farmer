public class Disk extends ComponentDecorator{
	Computer computer;
	public Disk(Computer computer){
		this.computer=computer;
	}
	public String description(){
		String s=computer.description()+ " and a disk";
		return s;
	}
}