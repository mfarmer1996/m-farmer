class concreteDecoratorB extends Decorator{
		public String method(){
		super.method()+ " and a Monitor";
	}
}