public class CD extends ComponentDecorator{
	Computer computer;
	public CD ( Computer computer){
		this.computer=computer;
	}
	public String description(){
		String s=computer.description()+" and a CD";
		return s;
	}
}