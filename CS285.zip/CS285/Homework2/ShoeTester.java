import java.util.*;
/**
 * Main class, tests Shoe.
 * @author Michael Rogers
 * @date 10/3/2017
 * @student_ID m14004758
 */
public class ShoeTester{
    public static void main(String []args){

        ArrayList<Shoe> shoes = new ArrayList<Shoe>();
        Comparator<Shoe> colorComp = new ShoesSortByColor();
        Comparator<Shoe> brandComp = new ShoesSortByBrand();

        shoes.add(new Shoe(8,"Adidas","Green"));
        shoes.add(new Shoe(10,"Nike","Red"));
        shoes.add(new Shoe(9,"Puma","Yellow"));
        shoes.add(new Shoe(11,"New Balance","White"));
        shoes.add(new Shoe(7,"Under Armor","Black"));



        System.out.print("----------------------------------------\nSort based on Size\n\n");
        Collections.sort(shoes);
        for(Shoe shoe : shoes){
            System.out.println("Shoe size is " + shoe.getSize() +
                    " ,brand: " + shoe.getBrand() +" ,color : " + shoe.getColor());
        }
        System.out.print("----------------------------------------\nSort Based on Brand\n\n");
        Collections.sort(shoes, brandComp);
        for(Shoe shoe : shoes){
            System.out.println("Shoe size is " + shoe.getSize() +
                    " ,brand: " + shoe.getBrand() +" ,color : " + shoe.getColor());
        }

        System.out.print("----------------------------------------\nSort Based on Color\n\n");
        Collections.sort(shoes, colorComp);
        for(Shoe shoe : shoes){
            System.out.println("Shoe size is " + shoe.getSize() +
                    " ,brand: " + shoe.getBrand() +" ,color : " + shoe.getColor());
        }
    }
}