import java.util.*;
/**
 * Models a shoe and houses a method to compare shoes by size.
 * @author Michael Rogers
 * @date 10/3/2017
 * @student_ID m14004758
 */
public class Shoe implements Comparable<Shoe>{

    /* vars */
    private int size;
    private String brand;
    private String color;

    /**
     * Constructs an object of Shoe.
     * @param size the size of the shoe
     * @param brand the brand of the shoe
     * @param color the color of the shoe
     */
    public Shoe(int size, String brand, String color){
        this.size = size;
        this.brand = brand;
        this.color = color;
    }

    /* getters */
    public int getSize() {
        return size;
    }

    public String getBrand() {
        return brand;
    }

    public String getColor() {
        return color;
    }

    /* setters */
    public void setSize(int size) {
        this.size = size;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Override
    /**
     * compares two integers
     * @param other the other size
     * @return int -1 if less than, 1 if greater than, 0 if equal
     */
    public int compareTo(Shoe other){
        if(size < other.size) return -1;
        if(size > other.size) return 1;
        return 0;
    }

}