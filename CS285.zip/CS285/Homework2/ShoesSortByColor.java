import java.util.*;

/**
 * Houses a custom comparator for comparing two shoes by Color.
 * @author Michael Rogers
 * @date 10/3/2017
 * @student_ID m14004758
 */
public class ShoesSortByColor implements Comparator<Shoe>
{
    public int compare(Shoe shoe1, Shoe shoe2)
    {
        return shoe1.getColor().compareTo(shoe2.getColor());
    }

}
