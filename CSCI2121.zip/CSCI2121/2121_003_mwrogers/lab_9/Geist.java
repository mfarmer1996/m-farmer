/**
 * An Adapter class for Ghost that converts it to a
 *German-Language interface
 *
 * @author Michael Rogers
 * @date 4/17/17
 */
 public class Geist{
     private Ghost myGhost;

     public Geist(String name){
         this.myGhost = new Ghost(name);
     }

     public void herumgeistern(){
         this.myGhost.haunt();
     }

     public void erschreken() {
         this.myGhost.scare();
     }



 }