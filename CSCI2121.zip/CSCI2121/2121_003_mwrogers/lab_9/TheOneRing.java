/**
 * A class that implements the Singleton
 * design pattern.
 *
 * @author	Franklin D. Worrell
 * @revised	31 October 2016
 */
public class TheOneRing {
    private String bearer;                   // the ring's bearer
    private static TheOneRing instance = null;// reference to the lone instance

    /**
     * Constructs an instance of bearer and sets it
     * to Sauron the Deceiver.
     */
    private TheOneRing() {
        this.bearer = "Sauron the Deceiver";
    }

    /**
     * Returns the instance of TheOneRing if it exists
     * otherwise, creates a new instance and returns a
     * referecne to that new instance.
     * @return a reference to the TheOneRing instance
     */
    public static TheOneRing getInstance() {
        if(instance == null){
            instance = new TheOneRing();
        }
        return instance;
    }
    /**
     * Reveals the ring's secrets to the clever wizard.
     */
    public void castIntoTheFire() {
        System.out.println();
        System.out.println("One Ring to rule them all, One Ring to find them, ");
        System.out.println("One Ring to bring them all and in the darkness bind them. ");
        System.out.println();
    } // end method castIntoTheFire
} // end class TheOneRing