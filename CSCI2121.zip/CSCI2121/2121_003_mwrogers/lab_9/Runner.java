public class Runner {
    public static void main(String args[]){
        TheOneRing ring = TheOneRing.getInstance();
        ring.castIntoTheFire();

        TheOneRing secondRing = TheOneRing.getInstance();
        System.out.println(ring.equals(secondRing));
        System.out.println();

        Geist myGeist = new Geist("Jacob Marley");
        myGeist.herumgeistern();
        myGeist.erschreken();
    }
}