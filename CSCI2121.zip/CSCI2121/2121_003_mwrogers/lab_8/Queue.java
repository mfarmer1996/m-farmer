import java.util.*;
public class Queue<T>
{
    private T[] array;
    private int head;
    private int tail;
    private int size;

    @SuppressWarnings("unchecked")
    public Queue()
    {
        this.size = 5;
        this.array = (T[]) new Object[this.size];
        this.head = this.tail = 0;
    }

    private boolean isEmpty()
    {
        if(this.tail == this.head)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public T dequeue() throws NoSuchElementException
    {
        if(isEmpty())
        {
            throw new NoSuchElementException("Queue is empty.");
        }
        else
        {
            T tempElement = this.array[this.head];
            this.head = (this.head + 1)%this.size;
            return tempElement;
        }
    }

    public boolean isFull()
    {
        if ((this.tail + 1) % this.size == this.head)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    @SuppressWarnings("unchecked")
    private void resizeArray()
    {
        T[] tempArray = (T[]) new Object[(this.size*2)];
        int elementsCopied = 0;//Number of elemements carried
        for(int index = this.head; index != this.tail; index = ((index+1)%this.size)){
            tempArray[elementsCopied] = this.array[index];
            elementsCopied++;
        }

        //update all the instance variables
        this.array = tempArray;
        this.head = 0;
        this.tail = elementsCopied;
        this.size*=2;
    }

    public void enqueue(T element)
    {
        if(isFull())
        {
            resizeArray();
        }
        //Add the element to the end of the Queue
        this.array[this.tail] = element;
        this.tail = (this.tail + 1) % this.size;
    }




}