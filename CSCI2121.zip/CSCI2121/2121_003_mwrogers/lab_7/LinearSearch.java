import java.util.*;
/**
 * Static methods to perform LinearSearch.
 * @author Michael Rogers
 * @revised 03/27/17
 */
public class LinearSearch{
    /**
     * Implements the linear search algorithm.
     * Returns the index of the first instance of the value if found.
     * @param list the ArrayList being searched
     * @param value the search query value
     * @Returns the index of the value if found, if not found -1.
     */
    public static <T extends Comparable<T>>int linearSearch(ArrayList<T> list, T value){
        int valueIndex = -1;
        for(int i = 0; i < list.size(); i++) {
            if(list.get(i).compareTo(value) == 0) {
                valueIndex = i;
            }
        }return valueIndex;
    }
}