import java.util.*;
/**
 * Sorts an object using SelectionSort
 * @author Michael Rogers
 * @revised 03/27/17
 */
public class SelectionSort{
    private static int startIndex = 0;
    private static int min;
    private static <T extends Comparable<T>>int findMin(ArrayList<T> list, int startIndex){
        //set min to start index
        int indexOfMin = startIndex;
        //iterate through the list
        for(int i = startIndex; i < list.size(); i++){
            if(list.get(i).compareTo(list.get(indexOfMin)) < 0){
                indexOfMin = i;
            }
        }
        //return index of min
        return indexOfMin;
    }

    public static <T extends Comparable<T>>void swap(ArrayList<T> list, int firstIndex, int secondIndex){
        T temp = list.get(firstIndex);
        list.set(firstIndex, list.get(secondIndex));
        list.set(secondIndex, temp);
    }

    public static <T extends Comparable<T>> void sort(ArrayList<T> list){
        sort(list,0);
    }

    private static <T extends Comparable<T>>void sort(ArrayList<T> list, int startIndex){
        if(startIndex < (list.size() -1)) {
            swap(list, startIndex, findMin(list, startIndex));
            sort(list, ++startIndex);
        }
    }
}