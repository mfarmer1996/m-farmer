/**
 * @author: Michael Rogers
 * @date: 2017-03-06
 *
 * Class Recursion contains helper methods to return the factorial of a
 * passed int n.
 */
public class Recursion{
    private static int n;

    /**
     *Returns the factorial of the number passed as argument by
     * accumulating the product with each successive call.
     * @param n the factorial to be calculated
     * @return the factorial
     */
    public static int tailFactorial(int n){
        //return the factorial of n
        return tailFactorial(n,1);
    }

    /**
     *Returns the product of n*(n-1)
     * @param n the factorial to be calculated
     * @param product   the accumulated product of the factorial calculation
     * @require (n>=0)
     * @return the factorial
     */
    public static int tailFactorial(int n, int product){
        //if n is 0 return 1 because 0! = 1
        if (n == 0){
            return product;
        }
        //if n !=0 return n*(n-1) and recursively pass n-1 to tailFactorial
        else{
            return n*tailFactorial((n-1));
        }
    }
}