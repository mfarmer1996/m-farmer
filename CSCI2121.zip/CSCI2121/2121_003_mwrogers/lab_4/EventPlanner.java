import java.util.ArrayList;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.EOFException;

/**
 * Stores a set of <code>Events</code> in an
 * <code>ArrayList</code> for processing and
 * printing. Allows the <code>Events</code>
 * to be serialized and stored to a file for
 * saving them between runs of the program.
 *
 * @author	Michael Rogers
 * @version	2/13/17
 * @see	Event
 * @see Runner
 */
public class EventPlanner {
    ArrayList<Event> events; 						// List of Events to process.
    ObjectOutputStream serializationOutput = null; 	// Streams for serialization.
    ObjectInputStream deserializationInput = null;


    /**
     * Constructor initializes the ArrayList of Events and
     * leaves it empty.
     */
    public EventPlanner() {
        this.events = new ArrayList<Event>();
    } // end constructor


    /**
     * Adds two precreated Event instances to the ArrayList.
     */
    public void addEvents() {
        this.events.add(new Event( "Redmann's Party", "2014-03-03 22:00", "Redmann's House", "Come pass a good time" ));
        this.events.add(new Event( "CSCI 2120 Test", "2014-03-24 16:30", "MATH 226", "2nd Test" ));
    } // end method addEvents


    /**
     * Prints the EventPlanner instance's contents.
     */
    public void printEvents() {
        // Planner is empty, inform the user.
        if (this.events.size() < 1) {
            System.out.println("Planner is empty.");
        }

        // Otherwise print the Events.
        else {
            for (Event event : this.events) {
                System.out.println(event.toString());
                System.out.println();
            }
        }
    } // end method printEvents


    /**
     * Clears all the Events from this.
     */
    public void clearSchedule() {
        this.events.clear();
    } // end method clearSchedule


    /**
     * Opens an ObjectOutputStream to serialize the contents
     * of the ArrayList of Events.
     */
    public void openOutputStream() {
        try{
            serializationOutput = new ObjectOutputStream(new FileOutputStream("myEvent.ser"));
        }
        catch (IOException e){
            System.out.println("Error opening file for serialization.");
            System.exit(1); //Terminate program and signal error to OS
        }
    } // end method openOutputStream


    /**
     * Serializes the Events in the ArrayList and writes
     * them to the ObjectOutputStream.
     */
    public void writeObjects() {
		try{
		    for(Event event : events){
		        serializationOutput.writeObject(event);
            }
        }
        catch (IOException e){
		    System.out.println("Error writing Object to file.");
		    System.exit(1); //Terminate program and signal error to OS
        }
        catch(NullPointerException e){
            System.out.println("OutputStream not previously opened.");
            System.exit(1); //Terminate program and signal error to OS
        }
    } // end method writeObjects


    /**
     * Closes an ObjectOutputStream.
     *
     * @throws IOException e, NullPointerException e.
     */
    public void closeOutputStream() {
		try{
		    serializationOutput.close();
        }
        catch (IOException e){
		    System.out.println("Error closing file.");
        }
        catch(NullPointerException e) {
            System.out.println("OutputStream not previously opened.");
            System.exit(1); //Terminate program and signal error to OS
        }
    } // end method closeOutputStream


    /**
     *Opens a new InputStream.
     *
     * @throws IOException e.
     */
    public void openInputStream() {
		try{
		    deserializationInput = new ObjectInputStream(new FileInputStream("myEvent.ser"));
        }
        catch (IOException e){
		    System.out.println("Error opening deserialization file.");
            System.exit(1); //Terminate program and report OS
        }
    } // end method openInputStream


    /**
     * Deserializes stored .ser files and outputs the data to
     * the user.
     *
     * @throws NullPointerException e, IOException e,
     * EOFException e, ClassNotFoundException e.
     */
    public void readObjects() {
		try{
		    while(true){
		        events.add( (Event) deserializationInput.readObject());
            }
        }
        catch(NullPointerException e) {
            System.out.println("InputStream not previously opened.");
            System.exit(1); //Terminate program and report OS
        }
        catch (EOFException e){
		    System.out.println("Read through end of serialized events. \n");
        }
        catch (IOException e){
            System.out.println("Error reading from serialization file.");
            System.exit(1); //Terminate program and report OS
        }
        catch (ClassNotFoundException e){
            System.out.println("Object type invalid.");
            System.exit(1); //Terminate program and report OS
        }
    } // end method readObjects


    /**
     *Closes an InputStream.
     *
     * @throws NullPointerException e, IOException e.
     */
    public void closeInputStream() {
        try{
            deserializationInput.close();
        }
        catch(NullPointerException e) {
            System.out.println("InputStream not previously opened.");
            System.exit(1); //Terminate program and report OS
        }
        catch (IOException e){
            System.out.println("Error closing deserialization file.");
            System.exit(1); //Terminate program and report OS
        }
    } // end method closeInputStream
} // end class Calendar