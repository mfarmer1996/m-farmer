/**
 * @author: Michael Rogers
 * @date: 3/13/2017
 *@Description: Lab 6 exercises with Linked Lists and Iterators
 */
import java.util.*; //access linkedlist and listiterator
public class IntegerList{
    //List
    private static Integer[] numbers = {7, 2, 5, 9, 4, 10, 21, 31, 6, 19, 2, 32, 21};
    private static LinkedList<Integer> data = new LinkedList<Integer>(Arrays.asList(numbers));
    private static ListIterator<Integer> iterator = new ListIterator<Integer>(Arrays.asList(numbers));
    //Main
    public static void main(String[] args){
        //For loop
        for(int i = 0; i < data.size(); i++)
        {
            //If int at i is even
            if ( (data.get(i) & 1) == 0 )
            {
                //Print the number
                System.out.print(data.get(i));
                //Remove the number at i
                data.remove(i);
                //Indicate that the variable has been removed
                System.out.println("    Has been removed.");
                i--;
            }
            else
            {
                //Just print the odd number
                System.out.println(data.get(i));
            }
        }
        //Print the new list
        System.out.print("The new List: ");
        System.out.println(data.toString());

        data = new LinkesList<Integer>()
    }

}