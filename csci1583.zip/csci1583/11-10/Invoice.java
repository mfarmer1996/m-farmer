public class Invoice implements Payable
{
    //attributes for invoice
    private double totalCost;
    private String name;
    private String id;
    
    public Invoice(double cost, String name, String id)
    {
        this.totalCost = cost;
        this.name = name;
        this.id = id;
    }
    
    //get cost
    public double getCost()
    {
        return this.totalCost;
    }
    
    //toSTring
    public String toString()
    {
        return String.format("Invoice# %s\n%s: $%.02d", 
                             this.id,
                             this.name,
                             this.totalCost);
    }
}