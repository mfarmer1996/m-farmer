public class FinalTestB extends FinalTestA
{
    private int y;
    
    public class FinalTestA(int x, int y)
    {   
        super(x);
        this.setX(x);
    }
    
    public final void SetX(int x)
    {
        this.y = x;
    }
}