public class FinalTestA
{
    private int x;
    
    public class FinalTestA(int x)
    {
        this.setX(x);
    }
    
    public void SetX(int x)
    {
        this.x = x;
    }
}