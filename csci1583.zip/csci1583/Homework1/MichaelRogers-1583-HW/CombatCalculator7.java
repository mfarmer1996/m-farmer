import java.util.Scanner;
public class CombatCalculator7
{
    public static void main(String[] args)
    {
        //Initialize monster name variable and set it to "Goblin"
        String monsterName = "Goblin";
        //Initialize monster health variable and set it 100
        int monsterHealth = 100;
        //Initialize monster attack power variable and set it to 15
        int monsterAttackPower = 15;
        //Initialize player health variable and set it 100
        int playerHealth = 100;
        //Initialize player attack power variable and set it to 12
        int playerAttackPower = 12;
        //Initialize player magic power variable and set it o 0
        int playerMana = 0;
        //Initialize a variable for user input
        int playerChoice;
        //Initialize loop control variable and set it to true
        boolean loopControl = true;
        //While the loop variable is true
        while (monsterHealth > 0 && playerHealth > 0 && loopControl == true)
        {       
                //Report Combat Stats
                //Print the Monsters name
                System.out.printf("You are fighting a %s!\n", MonsterName);
                //Print the Monsters health
                System.out.printf("The Monster HP: %d", MonsterHealth);
                //Print the pLayers health
                System.out.printf("\nYour HP: %d", PlayerHealth);
                //Print the players magic points
                System.out.printf("\nYour MP: %d\n", PlayerMana);
                
                
                //Combat menu prompt
                System.out.print("\nCombat Options:\n");
                //Print option 1: Sword Attack
                System.out.print("  1.) Sword Attack\n");
                //Print option 2: Cast Spell
                System.out.print("  2.) Cast Spell\n");
                //Print option 3: Charge Mana
                System.out.print("  3.) Charge Mana\n");
                //Print option 4: Run Away
                System.out.print("  4.) Run Away\n");
                //Prompt user for input
                System.out.print("What action do you want to perform?   ");
                
                
                        //Get player's input
                        Scanner input = new Scanner(System.in);
                        PlayerChoice = input.nextInt();
                        
                        
                                //if player chose option 1 check with equality operator
                                if (PlayerChoice == 1)
                                {
                                    //calculate damage and monster health using subtraction
                                    MonsterHealth = MonsterHealth - PlayerAttackPower;
                                    //print attack message
                                    System.out.printf("\nYou strike the goblin with your sword for %d damage.\n", PlayerAttackPower);
                                }
                                
                                
                                //if player chose option 2 check with equality operator
                                else if(PlayerChoice == 2)
                                {   
                                        //if player chose option two and has 3+ Mana points check with equality operator
                                        if (PlayerMana >= 3)
                                        {
                                        //Calculate the Monsters health by using division
                                        MonsterHealth = (MonsterHealth)/2;
                                        //Print attack message
                                        System.out.printf("\nYou cast the weaken spell on the monster.\n");
                                        //Cakculate the player's mp by, reduce the player's mana points by 3 using subtraction
                                        PlayerMana = PlayerMana - 3;
                                        }
                                        //if player chose option two and does not have 3+ mana points create an else statement
                                        else
                                        {
                                            //Print message to the player saying you do not have enough mana.
                                            System.out.print("\nYou don't have enough mana.\n");
                                        }
                                }
                                
                                
                                //if player chose option 3 check with equality operator
                                else if(PlayerChoice == 3)
                                {
                                    //Calculate the player's mana points using addition
                                    PlayerMana++;
                                    //Print message to user saying You focus and charge your magic power
                                    System.out.print("\nYou focus and charge your magic power.\n");
                                }
                                
                                
                                //if player chose option 4 check with equality operator
                                else if(PlayerChoice == 4)
                                {
                                    //Print message to user saying You run away
                                    System.out.print("\nYou run away!\n"); 
                                    //End the while loop by setting the loop control variable to false
                                    LoopControl = false;
                                }
                                
                                
                                //Create an else statement if the user selects an option other than those listed
                                else
                                {
                                    //Print a message to the user saying please select a valid option
                                    System.out.println("\nPlease select a valid option.");
                                }
                                
                                
                                //Create an if statement, if the player chose and option other than run away, the goblin will deal damage to the player
                                if (PlayerChoice != 4)
                                {
                                //calculate damage and player health using subtraction
                                PlayerHealth = PlayerHealth - MonsterAttackPower;
                                //print monster attack message
                                System.out.printf("\nThe %s strikes you for %d damage.\n\n", MonsterName, MonsterAttackPower);
                                }
                
                
                //create an if statement, if the monster's health is less than or equal to 0 
                if (MonsterHealth <= 0)
                {
                    //set the loop control variable to false to end the while loop
                    LoopControl = false;
                    //print a victory message to the user
                    System.out.printf("You have defeated the %s.\n", MonsterName);
                }
                
                
                //create an if statement, if the player's health is less than or equal to 0
                if (PlayerHealth <= 0)
                {
                    //set the loop control variable to false to end the while loop
                    LoopControl = false;
                    //print a defeat message to the user
                    System.out.print("You have been defeated.\n");
                }
        }
    }
}