//Determine the outcome from a player's actions in combat against a monster.
import java.util.Scanner;
public class CombatSystem
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        // initialize monster and player variables
        String MonsterName = "Goblin";
        
        int PlayerHealth = 100;
        int PlayerMana = 0;
        int PlayerAttackPower = 12;
        int PlayerSpellPower = 40;
        
        int MonsterHealth = 100;
        int MonsterAttackPower = 15;
        
        int choice;
        // print the starting monster and player stats
        System.out.printf("You are fighting a %s!\n", MonsterName);
        System.out.printf("The Monster HP: %d", MonsterHealth);
        System.out.printf("\nYour HP: %d", PlayerHealth);
        System.out.printf("\nYour MP: %d\n", PlayerMana);
        // initialize a while loop under the condition of monster health and player health greater than 0
        while (MonsterHealth > 0 && PlayerHealth > 0)
        {   //print combat options
            System.out.print("\nCombat Options:\n   1.) Sword Attack\n   2.) Cast Spell\n   3.) Charge Mana\n   4.) Run Away\nWhat action do you want to perform? ");
            //scan for input from the user
            choice = input.nextInt();
            //set up an if statement if the user selects option 1, calculate damage and print to the user
            if(choice == 1)
            {
                MonsterHealth = MonsterHealth - PlayerAttackPower;
                System.out.printf("\nYou strike the goblin with your sword for %d damage.\n", PlayerAttackPower);
            }
            //set up an if statement if the user selects option 2, and the user has charged 3 manapower, calculate damage and print to user
            else if(choice == 2 && PlayerMana >= 3) 
            
            {
                MonsterHealth = (MonsterHealth)/2;
                System.out.printf("\nYou cast the weaken spell on the monster.\n");
                PlayerMana = PlayerMana - 3;
            }
            //set up an if statement if the user selects option two, and has less than 3 manapower, print to user you need more mana
            else if(choice == 2 && PlayerMana < 3)
            {
                System.out.println("\nYou don't have enough mana.");
            }
            //set up an if statement if the user selects option three, add 1 manapower, print to the user they have charged mana
            else if(choice == 3)
            {
                 System.out.println("\nYou focus and charge your magic power.");
                 PlayerMana = PlayerMana + 1;
            }
            //set up an if statement if the user selects option four, break out of the while statement and print to the user they have ran away
            else if(choice == 4)
            {
                System.out.println("\nYou run away!."); 
                break;
            }    
            //set up an else statement if the user did not select 1 of the 4 options print to user to select a valid option
            else
            {
                System.out.println("\nPlease select a valid option.");
            }
            //set up an arithmetic output for the monster dealing damage to the player, calculate and print results to the user
            //calculate and print the updated player and monster variables to the user
            {
                System.out.printf("\nThe %s strikes you for %d damage.", MonsterName, MonsterAttackPower);
                PlayerHealth = PlayerHealth - MonsterAttackPower;
                System.out.printf("\n\nYou are fighting a %s!", MonsterName);
                System.out.printf("\nThe Monster HP: %d", MonsterHealth);
                System.out.printf("\nYour HP: %d", PlayerHealth);
                System.out.printf("\nYour MP: %d\n", PlayerMana);
                
            }
            
        }
        // set up an if statement, if the monster's health is less than 0 print a victory message
        if (MonsterHealth <= 0)
        {
            System.out.printf("\nYou have defeated the %s", MonsterName);
        }
        // set up an if statement, if the player's health is less than 0 print a defeat message
        if (PlayerHealth <= 0)
        {
            System.out.print("\nYou have been defeated.");
        }
    }  
}