import java.util.Random;
public class RandomTester
{
    public static void main(String[] args)
    {
        
        int[] frequency = new int [13];
        for (int i=0;i<1000000;i++)
        {
            int diceSum = rollDice();
            frequency[diceSum]++;
        }
        
        for(int element : frequency)
        {
            System.out.printf("%d\n",element);
        }
        
        
    }
    
    public static int rollDice()
    {
        Random randomGenerator = new Random();
        int die1 = randomGenerator.nextInt(6)+1;
        int die2 = randomGenerator.nextInt(6)+1;
        return die1 + die2;
    }
}    
    