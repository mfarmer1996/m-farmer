public class ArraySum
{
    public static void main(String[] args)
    {
        int[] array = {23,43,34,56,222};
        int sum = 0;
        for (int element : array)
        {
            sum += element;

        }
        System.out.printf("The sum is %d\n", sum);
        
        printArray(array);
        
        int[] y = array;
        printArray(y);
        
        for(int i=0;i<arrray.length;i++)
        {
            array[i]*=10;
        }
        for(int element : array)
        {
            System.out.println(x);
        }
        
        int[] y = array;
        
        for(int element : y)
        {
            System.out.println(x);
        }
        public static void printArray(int[] arr)
        {
            for(int element : arr)
            { 
                System.out.println(element);
            }    
        }
    }
}