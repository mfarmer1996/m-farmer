public class initArray
{
    public static void main(String[] args)
    {
        //initialize array
        int[] myArray = {12,45,76,112};
        
        for (int i=0; i<myArray.length; i++)
        {
            System.out.println(myArray[i]);
        }
    }
}
