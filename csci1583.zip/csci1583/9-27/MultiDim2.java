public class MultiDim2
{
    int[][] array = new int[5][];
    array[0] = new int[5];
    array[1] = new int[2];
}    
