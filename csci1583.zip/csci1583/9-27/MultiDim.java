public class MultiDim
{
    public static void main(String[] args)
    {
        String[i][j] name =   { 
                                {"Ted", "Alex", "Joe"}, 
                                {"Mary","Donald","Lily","Jerry","Tim"},
                                {"Bill", "Ed"} 
            
                            };
        
        for (int i=0; i<name[i].length; i++);
        {
            for (int j=0; j<name[i].length;j++);
            {
                String n = name [i][j];
                System.out.printf("%s", n);
            }
            System.out.println();
        }
        
        
    }
}
