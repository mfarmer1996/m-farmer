public class PassArray
{
    public static void main(String[] args)
    {
        int[] array = {1,2,3,4,5};
        System.out.println(array[3]);
        modifyElement(array[3]);
        System.out.println(array[3]);
        
        displayArray(array);
        modifyArray(array);
        displayArray(array);
        s
        
        
    }

    public static void displayArray(int[] arr)
    {
            for (intx : arr)
            {
                System.out.printf("%d\n", x);
            }
    }
     public static void modifyArray(int[] arr)
     {
         for (int i=0); i<arr.length; i++)
         {
             arr[i] *= 5;
         }
     }
     
    
    
}