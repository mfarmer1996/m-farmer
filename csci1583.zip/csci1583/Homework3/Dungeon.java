// create a game world/ dungeon/ allow the player to navigate around in this dungeon
//@Author: Michael Rogers
//10.12.2016


//import scanner utility
import java.util.Scanner;
//declare class Dungeon
public class Dungeon
{
    
    
    //set a variable for the final number of rooms
    final static int NUMBER_OF_ROOMS = 7;
    //set a constant variable to hold the value of NORTH
    final static int NORTH = 0;
    //set a constant variable to hold the value of EAST
    final static int EAST = 1;
    //set a constant variable to hold the value of WEST
    final static int WEST = 2;
    //set a constant variable to hold the value of SOUTH
    final static int SOUTH = 3;
    //set a loop control variable and initialize it to true
    private static boolean loopControl = true;
    //set a variable to hold the current room number and initialize it to 0
    private static int current = 0;
    //set a variable to receive input from the user
    private static String userInput;
    
    
    //create a class array of strings which holds a description for each room
    private static String[] roomDescription =   
                                                {
                                                //index 0 = dark dark room
                                                "You are in the dark dark room, exits are North and East.\n",
                                                //index 1 = evil dark dungeon
                                                "You are in the evil dark dungeon, exits are North, East, and West.\n",
                                                //index 2 = messy bloody room
                                                "You are in the messy bloody room, exits are North and West.\n",
                                                //index 3 = the ghost of the shadow room
                                                "You are in the ghost of the shadow room, exits are East and South.\n",
                                                //index 4 = the haunted house room
                                                "You are in the haunted house room, exits are North, East, West, and South.\n",
                                                //index 5 = jail
                                                "You are in the jail room, exits are West and South.\n",
                                                //index 6 = the scary room
                                                "You are in the scary room, exits are South.\n"
                                                };
                                        
                                        
        //create a class multidimensional array to hold the exits for each room
        private static int[][] roomExits =  {               
                                                           //n  e  w  s
                                               /*Index 0*/ { 3, 1,-1,-1},
                                               /*Index 1*/ { 4, 2, 0,-1},
                                               /*Index 2*/ { 5,-1, 1,-1},
                                               /*Index 3*/ {-1, 4,-1, 0},
                                               /*Index 4*/ { 6, 5, 3, 1},
                                               /*Index 5*/ {-1,-1, 4, 2},
                                               /*Index 6*/ {-1,-1,-1, 4}
                                           };
                                


    
    
                //main method
                public static void main(String[] args)
                {  
                    // set up while loop, initialize control variable to true, continue the game until the user decides to quit
                    while (loopControl == true)
                    {
                        //print the current room and it's description
                        System.out.print(roomDescription[current]);
                        //invoke the getUserInput method to get input from the user
                        getUserInput();
                        //invoke the calculateMovement method to update the player's position based on the input received
                        calculateMovement(userInput);
                    }
                    
                }//end main
                
                
                
                
                
                
                
                
                //create a method responsible for getting input from the user
                public static void getUserInput()
                            {
                                    //print the movement options to the user
                                    System.out.println("\nn) to go north\ns) to go south\ne) to go east\nw) to go west\nq) to quit");
                                    //create a new scanner object
                                    Scanner input = new Scanner(System.in);
                                    //create a string variable and initialize it equal to the next user input
                                    String userInput = input.nextLine();
                                    //initialize the class variable userInput equal to the local variable userInput
                                    Dungeon.userInput = userInput;
                                    
                            }//end getUserInput method
                            
                
    
                            
                                
                            
                            
    
                            //create a method which accepts userInput responsible for holding the movement algorithm 
                            private static void calculateMovement(String userInput)
                            {           
                                        //set equality operator if user input equals ignore case "n"
                                        if (userInput.equalsIgnoreCase("n"))
                                        {   
                                            //if the int value at roomExits[current][NORTH] is equal to -1
                                            if(roomExits[current][NORTH] == -1)
                                            {
                                                //print to the user that they cant go in that direction
                                                System.out.println("You cannot go that way.");
                                            }
                                            //else if the int value at roomExits[current][NORTH] is not equal to -1
                                            else if(roomExits[current][NORTH] != -1)
                                            {
                                                /*change the value of the current room to the value of the 
                                                integer at roomExits[current][NORTH]*/
                                                current = roomExits[current][NORTH];
                                            }  
                                        }
                                        
                                        
                                        
                                        
                                        //set equality operator if user input equals ignore case "e"
                                        else if(userInput.equalsIgnoreCase("e"))
                                        {   
                                            //if the int value at roomExits[current][EAST] is equal to -1
                                            if(roomExits[current][EAST] == -1)
                                            {   
                                                //print to the user that they cant go in that direction
                                                System.out.println("You cannot go that way.");
                                            }
                                            //else if the int value at roomExits[current][EAST] is not equal to -1
                                            else if(roomExits[current][EAST] != -1)
                                            {
                                                /*change the value of the current room to the value of the 
                                                integer at roomExits[current][EAST]*/
                                                current = roomExits[current][EAST];
                                            }  
                                        }
                                        
                                        
                                        
                                        
                                        //set equality operator if user input equals ignore case "s"
                                        else if (userInput.equalsIgnoreCase("s"))
                                        {   
                                            //if the int value at roomExits[current][SOUTH] is equal to -1
                                            if(roomExits[current][SOUTH] == -1)
                                            {
                                                //print to the user that they cant go in that direction
                                                System.out.println("You cannot go that way.");
                                            }
                                            //else if the int value at roomExits[current][SOUTH] is not equal to -1
                                            else if(roomExits[current][SOUTH] != -1)
                                            {
                                                /*change the value of the current room to the value of the 
                                                integer at roomExits[current][SOUTH]*/
                                                current = roomExits[current][SOUTH];
                                            }  
                                        }
                                        
                                        
                                        
                                        
                                        //set equality operator if user input equals ignore case "w"
                                        else if (userInput.equalsIgnoreCase("w"))
                                        {
                                            //if the int value at roomExits[current][WEST] is equal to -1
                                            if(roomExits[current][WEST] == -1)
                                            {
                                                //print to the user "You cannot go that way." 
                                                System.out.println("You cannot go that way.");
                                            }
                                          
                                            //else if the int value at roomExits[current][WEST] is not equal to -1
                                            else if(roomExits[current][WEST] != -1)
                                            {
                                                /*change the value of the current room to the value of the 
                                                integer at roomExits[current][WEST]*/
                                                current = roomExits[current][WEST];
                                            }  
                                        }
                                        
                                        
                                        //set equality operator if user input equals ignore case "q"
                                        else if(userInput.equalsIgnoreCase("q"))
                                        {
                                            //set loop control variable to true to end the program
                                            gameOver = true;
                                            
                                            
                                        }
                                        
                                        //else any other input
                                        else
                                            {
                                                //print an error statement to the user 
                                                System.out.println("Please select a valid option.");
                                            }
                                            
                            }//end movementCalculator method
                            
                            
                            
                            
    
}//end Dungeon class