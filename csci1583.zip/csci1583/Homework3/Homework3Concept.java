// create a game world/ dungeon/ allow the player to navigate around in this dungeon
// game map / collection of rooms/ dungeon = collection of rooms
// array = dungeon
// array holds different rooms int[6] dungeon = {0,1,2,3,4,5,6}
// one exit per cardinal direction
// GB = 0 SH = 1 D = 2 MB = 3 NH = 4 K = 5 B = 6
// EXITS N E W S 
// express a -1 to directions which arent valid
// if input == north
// current = exits[current][NORTH]
// 
