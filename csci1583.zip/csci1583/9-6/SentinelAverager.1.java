//Determine the class average for quizes.
import java.util.Scanner;
public class SentinelAverager
{
    public static void main(String[] args)
    {
        //initialize sum to 0
        int sum = 0;
        //initialize count to 0
        int count = 0;
        //declare average
        double average;
        //declare a sentinel
        int grade;
        //initialize a scanner object
        Scanner input = new Scanner(System.in);
        //Prompt user a first time
        System.out.print("Enter a grade or -1 to quit:");
        grade = input.nextInt();
        //while grade is not -1
        while (grade != -1)
        {
            //Prompt user for grade
            System.out.print("Enter a grade or -1 to quit:");
            //Get grade from user
            grade = input.nextInt();
            //add to sum variable 
            sum += grade;
            //add sum to count
            count++;
        }
        //average
        average = (double)(sum)/ count;
        //Print average
        System.out.printf("The average is %f\n", average);
            
    }
}