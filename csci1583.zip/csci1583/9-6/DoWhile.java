public class DoWhile
{
    public static void main(String[] args)
    {   System.out.println("Before loop");
        int j = 11;
        do
        {
            System.out.printf("%d\n ", j);
            j++;
        }while (j<10);
        System.out.println("After loop");
    }
}
/// When you have to execute a variable atleast once