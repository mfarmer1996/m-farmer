//Determine the class average for quizes.
import java.util.Scanner;
public class SentinelAverager
{
    public static void main(String[] args)
    {
        //Refinement 1:
        //initialize variables
        //Input, sum, and count on quiz grades
        //declare the average
        
        //Refinement 2:
    
        
        //Prompt user for grade
        //get grade from user
        // add to sum variable the value of grade
        // add 1 to count variable
        
        //Average is sum / count
        //Print Average
        
        //Refinement 3:
        //while grade not -1
        //initialize sum to 0
        int sum = 0;
        //initialize count to 0
        int count = 0;
        //declare average
        double average;
        //declare a sentinel
        int grade;
        //initialize a scanner object
        Scanner input = new Scanner(System.in);
        //Prompt user a first time
        System.out.print("Enter a grade or -1 to quit:");
        grade = input.nextInt();
        //while grade is not -1
        while (grade != -1)
        {
            //Prompt user for grade
            System.out.print("Enter a grade or -1 to quit:");
            //Get grade from user
            grade = input.nextInt();
            //add to sum variable 
            sum += grade;
            //add sum to count
            count++;
        }
        if (count != 0)
        {
            //average
            average = (double)(sum)/ count;
            //Print average
            System.out.printf("The average is %f\n", average);
        }    
            
    }
}