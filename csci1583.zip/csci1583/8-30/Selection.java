// make a program that determines if you pass a class
import java.util.Scanner;

public class Selection
{//start class
    public static void main(String[] args)
    {//start main
        
        //declare a variable for class grade
        int grade;
        
        //Setup a scanner for input 
        Scanner input = new Scanner(System.in);
        
        //create repetition statement
        boolean repeat = true;
        while (repeat = true)
        {//start while
            {
            
            //prompt the user for input 
            System.out.print("Enter a grade: ");
            
            //get the user input
            grade = input.nextInt();
            
            if (grade >= 90)
            {
                //Report to user that they passed
                System.out.println("You got an A");
            }
            else if (grade >= 80)
            {
                //Report to user they got a B
                System.out.println("You got a B");
            }
            else if (grade >= 70)
            {
                //Report to user they got a C
                System.out.println("You got a C");
            }
            else if (grade >= 60)
            {
                //Report to user they got a D
                System.out.println("You got a D");
            }
            else if (grade < 60);
            {
                //Report to user they failed
                System.out.println("F");
            }
            
            System.out.println("Press 1 to enter a new grade, 0 to quit");
            int response = input.nextInt();
            repeat = (response == 1) ? true : false;
            
            }
            
        }//end while    
    }//end main
}//end class

