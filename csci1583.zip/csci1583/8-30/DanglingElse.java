public class Dangling Else
{
    public static void main(String[] args)
    {
        if (10>9)
        {
            if("a" = "A")
            {
                System.out.println("Hello");
            }
        }
    }
}