// make a program that determines if you pass a class
import java.util.Scanner;

public class Selection1
{//start class
    public static void main(String[] args)
    {//start main
        
        //declare a variable for class grade
        int grade;
        
        //Setup a scanner for input 
        Scanner input = new Scanner(System.in);
        
        //create repetition statement
        boolean repeat = true;
        while (repeat = true);
        {//start while
            {//start operations
            
            //prompt the user for input 
            System.out.print("Enter a grade: ");
            
            //get the user input
            grade = input.nextInt();
            
            if (grade >= 90);
            {
                //Report to user that they passed
                System.out.println("You got an A");
            }
        
            System.out.println("Press 1 to enter a new grade, 0 to quit");
            int response = input.nextInt();
            repeat = (response == 1) ? true : false;
            
            }//end operations
            
        }//end while    
    }//end main
}//end class

