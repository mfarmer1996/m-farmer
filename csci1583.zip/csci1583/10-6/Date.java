public class Date
{
    //Attribute for a Date
    private int year;
    private int month;
    private int day;
    
    //constructor
    public Date(int day, int month, int year)
    {
        this.day=day;
        this.month=month;
        this.year=year;
    }
    //getters
    public int getYear()
    {
        return this.year;
    }
    
    public int getMonth()
    {
        return this.month;
    }
    
    public int getDay()
    {
        return this.day;
    }
    
    public String toString()
    {
        return String.format("Day: %d  Month: %d  Year:  %d", this.day, this.month, this.year);
        
    }
//getters
    
    
}
