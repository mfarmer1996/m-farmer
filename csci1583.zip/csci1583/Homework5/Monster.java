import java.util.Scanner;
import java.util.Random;
public class Monster extends GameCharacter
{
    //attributes specific to Monster
    private static int xP;
    
    public Monster(String characterName, int characterHealth, int attackPower, int xP)
    {
        super(characterName, characterHealth, attackPower);
        this.xP = xP;
    }
    
    public void attack(Player thePlayer)
    {
        int a = thePlayer.getHealth() - this.getAttackPower();
        thePlayer.setHealth(a);
        
    }
    
    public void takeTurn(Player thePlayer)
    {
        this.attack(thePlayer);
    }
    
    public int getXP()
    {
        return this.xP;
    }
    
    public String toString()
    {
        String character = super.toString();
        return String.format("%s\nXP:%d", character, this.getXP());
    }
}