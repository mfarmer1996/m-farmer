import java.util.Random;
import java.util.Scanner;
public class Runner 
{
    //variable to hold monster appearance
    private static boolean monsterHere;
    //loop control variable
    private static boolean gameOver = false;
    //user input variable
    private static String userInput;
    //variable for WALL
    public static final Room WALL = null;
    //new variable for an instance of Dungeon
    private static Dungeon dungeon = new Dungeon();
    //new variable to hold current room, set equal to getRoom0
    private static Room currentRoom = dungeon.getRoom0();
    
    //new variable to hold instance of player
    private static Player thePlayer = new Player("Hero", 200, 10, 5);
    private static Monster theMonster;
    public static final Random rng = new Random();
    

    public static void main(String[] args)
    {
       while(gameOver == false && thePlayer.getHealth() > 0)
       {
           System.out.println(currentRoom);
           getUserInput();
           calculateMovement(userInput);
           int chance = rng.nextInt(100);
           if (chance <= 20)
           {   
                monsterHere = true;
                theMonster = generateMonster();
           }
           if (monsterHere == true && gameOver == false)
           {
                enterCombat(theMonster);
                thePlayer.setHealth(thePlayer.getHealth() + 20);
                thePlayer.setAttackPower(thePlayer.getAttackPower() + 20);
                monsterHere = false;
           }
       }
       printExitMessage();
    }
    
    public static void getUserInput()
    {
        //create a new scanner object
        Scanner input = new Scanner(System.in);
        //initialize userInput equal to the next user input
        userInput = input.nextLine();
    }//end getUserInput method
                            
    //create a method which accepts userInput responsible for holding the movement algorithm 
    private static void calculateMovement(String userInput)
    {           
        
        if (userInput.equalsIgnoreCase("n"))
        {   
            
            if(currentRoom.getNorth() == WALL)
            {
                System.out.println("You cannot go that way.");
            }
            else
            {
                currentRoom = currentRoom.getNorth();
            }  
        }
        else if(userInput.equalsIgnoreCase("e"))
        {   
            if(currentRoom.getEast() == WALL)
            {
                System.out.println("You cannot go that way.");
            }
            else
            {
                currentRoom = currentRoom.getEast();
            }  
        }
                                
        else if(userInput.equalsIgnoreCase("w"))
        {  
            if(currentRoom.getWest() == WALL)
            {
                System.out.println("You cannot go that way.");
            }
            else
            {
                currentRoom = currentRoom.getWest();
            }  
        }
                                        
        else if(userInput.equalsIgnoreCase("s"))
        {   
            if(currentRoom.getSouth() == WALL)
            {
                System.out.println("You cannot go that way.");
            }
            else
            {
                currentRoom = currentRoom.getSouth();
            } 
        }    
        else if(userInput.equalsIgnoreCase("q"))
        {
            monsterHere = false;
            gameOver = true;
            System.out.println("You have left the Dungeon.");
        }
                                    
        //else any other input
        else
        {
            System.out.println("Please select a valid option.");
        }
    }   
    
    public static Monster generateMonster() 
    {
        //create variables to hold random values for Monster
        String alphabet = "abcdefghijklmnopqrstuvwxyz";
        final int N = 10;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < N; i++)     
        {
            sb.append(alphabet.charAt(rng.nextInt(alphabet.length())));
        }
        String randomName = sb.toString();
        int randomAttackPower = rng.nextInt(50);
        int randomHealth = rng.nextInt(200);
        int randomXP = rng.nextInt(10);
        Monster theMonster = new Monster(randomName, randomHealth, randomAttackPower, randomXP);
        return theMonster;
    }

    public static void enterCombat(Monster theMonster)
    {
    
        while (thePlayer.getHealth() > 0 && theMonster.getHealth() > 0 && monsterHere == true)
        {
            System.out.printf("\nYou have encountered a %s, prepare to fight!\n\n", theMonster.getName());
        
            System.out.printf("Your HP: %d\n"+
                              "Your MP: %d\n"+
                              "Your AP: %d\n\n"+
                              "Monster HP: %d\n"+
                              "Monster AP: %d\n"+
                              "Monster XP: %d\n",
                              thePlayer.getHealth(), 
                              thePlayer.getMana(),
                              thePlayer.getAttackPower(),
                              theMonster.getHealth(),
                              theMonster.getAttackPower(),
                              theMonster.getXP()
                              );
                              
            System.out.println("\nWhat action would you like to perform?\n"+
                                "T) Sword Attack\n"+
                                "Y) Cast Spell\n"+
                                "U) Charge Mana\n"+
                                "I) Run Away");
                                
            getUserInput();
            
            if (userInput.equalsIgnoreCase("t"))
            {
                thePlayer.attack(theMonster);
            }
            else if (userInput.equalsIgnoreCase("y"))
            {
                thePlayer.castSpell(theMonster);
            }
            else if (userInput.equalsIgnoreCase("u"))
            {
                thePlayer.chargeMana();
            }
            else if (userInput.equalsIgnoreCase("i"))
            {
                System.out.printf("You ran away!\n");
                monsterHere = false;
            }
            else
            {
                System.out.println("Please select a valid option.");
            }
            
            theMonster.attack(thePlayer);
        }    
    }
    public static void printExitMessage()
    {
        System.out.println("Thank you for playing!");
    }
}    