public class Room
{
    private String roomDescription;
    private Room north;
    private Room south;
    private Room east;
    private Room west;
    private String roomName;
    
    public Room (String roomName, String roomDescription)
    {
        this.roomName = roomName;
        this.roomDescription = roomDescription;
    }
    //Setters
    
    //setNorth
    public void setNorth(Room north)
    {
        this.north = north;
    }
    
    //setEast
    public void setEast(Room east)
    {
        this.east = east;
    }
    //setWest
    public void setWest(Room west)
    {
        this.west = west;
    }
    //setSouth
    public void setSouth(Room south)
    {
        this.south = south;
    }

    //setExits
    public void setExits(Room n, Room e, Room w, Room s)
    {
        this.north = n;
        this.east = e;
        this.west = w;
        this.south = s;
    }
    //Getters
    
    public String getRoomName()
    {
        return this.roomName;
    }
    //getNorth
    public Room getNorth()
    {
        return this.north;
    }
    //getEast
    public Room getEast()
    {
        return this.east;
    }
    //getWest
    public Room getWest()
    {
        return this.west;
    }
    //getSouth
    public Room getSouth()
    {
        return this.south;
    }
        
    //getDescription
    public String getRoomDescription()
    {
        return this.roomDescription;
    }
    
    //getExits
    public String getExits()
    {
        return String.format("Exits are:\n" +
                             "[N]orth: %s\n"+
                             "[E]ast:  %s\n"+
                             "[W]est:  %s\n"+
                             "[S]outh: %s\n"+
                             "[Q]uit",
                            (this.north != null) ? this.getNorth().getRoomName() : "No Exit", 
                            (this.east != null) ? this.getEast().getRoomName() : "No Exit", 
                            (this.west != null) ? this.getWest().getRoomName() : "No Exit", 
                            (this.south != null) ? this.getSouth().getRoomName() : "No Exit");
    }
    //toString method
    public String toString()
    {
        return String.format("You are in the: %s\n %s\n %s", 
                              this.getRoomName(), 
                              this.getRoomDescription(), 
                              this.getExits());
    }
}