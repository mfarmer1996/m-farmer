import java.util.Scanner;
import java.util.Random;
public class Player extends GameCharacter
{
    //attributes specific to the Player subclass
    private int playerMana;
    
    public Player(String characterName, int characterHealth, int attackPower, int playerMana)
    {
        super(characterName, characterHealth, attackPower);
        this.playerMana = playerMana;
    }
    
    public void attack(Monster theMonster)
    {
        int a = theMonster.getHealth() - this.getAttackPower();
        theMonster.setHealth(a);
    }
    
    public void castSpell(Monster theMonster)
    {
        if (this.playerMana >= 3)
        {
            int a = theMonster.getHealth()/2;
            theMonster.setHealth(a);
            this.playerMana = playerMana - 3;
        }
        
        else
        {
            System.out.println("You don't have enough mana");
        }
    }
    
    public void chargeMana()
    {
        this.playerMana++;
    }
    
    public int getMana()
    {
        return this.playerMana;
    }
    
    
    public String toString()
    {
        String character = super.toString();
        return String.format("%s\nMP:%d", character, this.getMana());
    }
    

    
    
}
