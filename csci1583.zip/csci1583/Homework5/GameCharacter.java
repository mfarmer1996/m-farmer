import java.util.Scanner;
import java.util.Random;
public class GameCharacter
{
    Scanner rng = new Scanner(System.in);
    //attributes of a game character
    private String characterName;
    private int characterHealth;
    private int attackPower;
    
    public GameCharacter(String characterName, int characterHealth, int attackPower)
    {
        this.characterName = characterName;
        this.characterHealth = characterHealth;
        this.attackPower = attackPower;
    }
    
    public String getName()
    {
        return this.characterName;
    }
    
    public int getAttackPower()
    {
        return this.attackPower;
    }
    
    public int getHealth()
    {
        return this.characterHealth;
    }
    
    public void setHealth(int characterHealth)
    {
        this.characterHealth = characterHealth;
    }
    
    public void setAttackPower(int attackPower)
    {
        this.attackPower = attackPower;
    }
    
    public String toString()
    {
        return String.format("Name:%s\nHealth%d\nAP:%d", this.getName(), this.getHealth(), this.getAttackPower());
    }
}
