// create a game world/ dungeon/ allow the player to navigate around in this dungeon
//@Author: Michael Rogers
//10.26.2016

//declare class Dungeon
public class Dungeon
{
    //attributes of a dungeon  
    private Room balcony;
    private Room bedroom1;
    private Room bedroom2;
    private Room dining;
    private Room kitchen;
    private Room northHall;
    private Room southHall;
    
    //Dungeon constructor    
    public Dungeon()
    {
    
        //set up new instances of Room with the description of each room
        this.balcony = new Room("Balcony","Outdoor balcony overlooks the courtyard filled with flowers.");
        this.bedroom1 = new Room("Master Bedroom","A big bed lies in the center with a large window and closet.");
        this.bedroom2 = new Room("Guest Bedroom","Small cramped space with a tiny bed filled with hay.");
        this.dining = new Room("Dining room","You smell dinner on the table, a bright fluorescent light fills the room");
        this.kitchen = new Room("Kitchen","You see a big cauldron with bubbling stew a large cut of venison is on the counter.");
        this.northHall = new Room("North hall \u265B", "Dimly lit lanterns guide your steps, shadows crawl along your path");
        this.southHall = new Room("South hall","A slight mist clouds your vision, dim flickers attract moths, it smells of mold.");
        
        //set the exits for each room
        this.balcony.setSouth(northHall);
        
        this.bedroom1.setNorth(bedroom2);
        this.bedroom1.setEast(southHall);
        
        this.bedroom2.setEast(northHall);
        this.bedroom2.setSouth(southHall);
        
        this.dining.setNorth(kitchen);
        this.dining.setWest(southHall);
        
        this.kitchen.setWest(northHall);
        this.kitchen.setSouth(dining);
        
        this.northHall.setNorth(balcony);
        this.northHall.setSouth(southHall);
        this.northHall.setEast(kitchen);
        this.northHall.setWest(bedroom2);
        
        this.southHall.setNorth(northHall);
        this.southHall.setEast(dining);
        this.southHall.setWest(bedroom1);
        
    }
    //getRoom0 method, returns the starting room
    public Room getRoom0()
    {
        return this.bedroom1;
    }
    
    
    
                                            
                          
                            
                            
                            
                            
    
}//end Dungeon class