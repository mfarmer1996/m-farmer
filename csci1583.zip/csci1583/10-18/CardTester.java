public class CardTester
{
    public static void main(String[] args)
    {
        DeckOfCards deck = new DeckOfCards();
        for (int i =0; i<DeckOfCards.NUMBER_OF_CARDS; i++)
        {
            System.out.println(deck.deal());
        }
    }
}