public class Max
{
    public static void main(String[] args)
    {
        int result = maxValue(maxValue(3,5,28,), maxValue(6,32,8), maxValue(39,31,93));
        System.out.printf("the max value is %d", result);
    }
    
    public static int maxValue(int x, int y, int z)
    {
        int max = x;
        if (y > max)
        {
            max = y;
        }
        if (z > max)
        {
            max = z;
        }
        
        return max;
        
    }
}