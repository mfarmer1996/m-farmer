public class Concat
{
    public static void main(String[] args)
    {
        String x = "hello";
        int y = 23;
        int z = 14;
        System.out.println(x+(y+z));
    }
}