public class HelloThere
{
    public static void main(String[] args)
    {
        boolean aNumber = false; 
        System.out.printf("The int value is %b\n" , aNumber, 10);
        
    }
}