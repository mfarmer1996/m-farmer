public class HelloThere
{
    public static void main(String[] args)
    {
        float aNumber = 10; 
        System.out.printf("The int value is %d\n" , aNumber, 10);
        
    }
}