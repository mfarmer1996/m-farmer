public class HelloThere
{
    public static void main(String[] args)
    {
        int aNumber = 10; 
        System.out.printf("The int value is %d" , aNumber, 10);
        aNumber = 20;
        System.out.printf("The int value is %d\n" , aNumber, 20);
    
    }
}