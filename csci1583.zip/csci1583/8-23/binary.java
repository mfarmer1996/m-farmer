public class HelloThere
{
    public static void main(String[] args)
    {
        int x = 1 % 2;
        System.out.printf("The int value is %d\n";
        
    }
}