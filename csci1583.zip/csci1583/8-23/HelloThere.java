public class HelloThere
{
    public static void main(String[] args)
    {
        System.out.printf("Hello There");
    }
}