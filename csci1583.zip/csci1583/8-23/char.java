public class HelloThere
{
    public static void main(String[] args)
    {
        char aNumber = 'a'; 
        System.out.printf("The int value is %c\n" , aNumber, 10);
        
    }
}