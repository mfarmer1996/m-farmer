public class HelloThere
{
    public static void main(String[] args)
    {
        String aNumber = 'a'; 
        System.out.printf("The int value is %s\n" , aNumber, 10);
        
    }
}