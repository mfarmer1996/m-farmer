public class GameTester
{
    public static void main(String[] args)
    {
        GameCharacter gc = new Dragon("dragonslayer");
        Monster m = new Dragon("dragonslayerman");
        GameCharacter h = new Hero("FAF"):
        System.out.println(gc);
        System.out.println(m);
        
        if (m instanceof Dragon)
        {
            Dragon d = (Dragon) m;
            d.breathFire();
        }
    }
}