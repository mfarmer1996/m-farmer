public class Dragon extends Monster
{
    public Dragon(String name)
    {
        super(name);
        
    }
    
    public void attack(GameCharacter enemy)
    {
        System.out.println("The dragon attakcsxd");
    }
    
    public void breathFire()
    {
        System.out.println("breathbfire");
    }
    public String toString()
    {
        return super.toString() + "the dragon";
    }
}