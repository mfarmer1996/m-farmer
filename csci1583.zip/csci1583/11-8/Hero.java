public class Hero extends GameCharacter
{
    public Hero(String name)
    {
        super(name);
        
    }
    public String toString()
    {
        return super.toString() + "the Hero";
    }
}