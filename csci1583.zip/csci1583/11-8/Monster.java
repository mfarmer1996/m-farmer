public abstract class Monster extends GameCharacter
{
    public Monster(String name)
    {
        super(name);
        
    }
    
    public void getTreasure()
    {
        System.out.println("You found tresur");
    }
    
    public String toString()
    {
        return super.toString() + "the monster";
    }
}