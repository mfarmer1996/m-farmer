import java.util.Random;
public class Craps
{
    private enum Status {CONTINUE, LOST, WON}
    private static final int SNAKE_EYES = 2;
    private static final int TREY= 3;
    private static final int SEVEN = 7;
    private static final int YO = 11;
    private static final int BOXCARS = 12;
    
    private static Status gameStatus;
    private static int myPoint;
    
    
    
    public static void main(String[] args)
    {
        firstRound();
        while (gameStatus == Status.CONTINUE)
        {
            nextRound();
        }
        printResult();
        
    }       
    
    public static void firstRound()
    {
        //roll dice
        int diceSum = rollDice();
        
        int myPoint = diceSum;
        //did we win? (7,11)
        if (diceSum == SEVEN || diceSum == YO)
        {
            //we win
            gameStatus = Status.WON;
        }
        //did we lose? (2,3,12)
        else if (diceSum == SNAKE_EYES || diceSum == TREY || diceSum == BOXCARS)
        {
            //we lose
            System.out.println("You lose");
            gameStatus = Status.LOST;
        }
        //anything else goes to the next round
        else 
        {
            System.out.printf("Your point is %d\n", diceSum);
            gameStatus = Status.CONTINUE;
        }
    }   
    public static void nextRound()
    {
                //roll dice
                int diceSum = rollDice();
                //did we win?
                if (diceSum == myPoint)
                {
                    gameStatus = Status.WON;
                }
                
                
                if (diceSum == SEVEN)
                {
                    gameStatus = Status.LOST;
                }   
    }
    public static void printResult()
    {
                if (gameStatus == Status.WON)
                {
                    System.out.println("You won");
                }
                
                
                if (gameStatus == Status.LOST)
                {
                    System.out.println("You lost");
                }
    }
    public static int rollDice()
    {
        Random randomGenerator = new Random();
        int dice1 = randomGenerator.nextInt(6)+1;
        int dice2 = randomGenerator.nextInt(6)+1;
        int diceSum = dice1 + dice2;
        System.out.printf("%d+%d=%d\n", dice1, dice2, diceSum);
        return diceSum;
        
    }
}