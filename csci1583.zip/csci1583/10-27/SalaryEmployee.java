public class SalaryEmployee extends Employee
{
    private double monthlySalary;
    
    public SalaryEmployee(String firstName, String lastName, Date dateOfBirth, Date hireDate, double monthlySalary)
    {
        super(firstName, lastName, dateOfBirth, hireDate);
        if (salary <= 0)
        {
            throw new IllegalArgumentException("You must have a positive salary.")
        }
        this.setFirstName(firstName);
        this.monthlySalary = monthlySalary;
    }
    
    public double getMonthlySalary()
    {
        return this.monthlySalary;
    }
    
    public double getEarnings()
    {
        return this.monthlySalary()/2;
    }
    
    public String toString()
    {
        String employee = super.toString();
        employee = employee.replace("Employee", "Salary Employee");
        return String.format("%s\nSalary: %.02f", employee, this.monthlySalary);
    }
}