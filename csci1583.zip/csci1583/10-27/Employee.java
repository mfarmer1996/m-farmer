public class Employee
{
    private String firstName = "";
    private String lastName = "";
    private Date dateOfBirth;
    private Date hireDate;
    
    public Employee(String firstName,String lastName, Date dateOfBirth, Date hireDate)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.hireDate = hireDate;
        
    }
    
    public String getFirstName()
    {
        return this.firstName;
    }
    public String getLastName()
    {
        return this.lastName;
    }
    public Date getDateOfBirth()
    {
        return this.dateofBirth;
    }
    public Date getHireDate()
    {
        return this.hireDate;
    }
    public String toString()
    {
        return String.format("%s, %s\ndob:%s\nhire:%s\n",
                                this.getLastName()
                                this.getFirstName()
                                this.getDateOfBirth()
                                this.getHireDate()
                                );
        
    }
    /*  
        first:String
        last:String 
        dob:Date
        hireDate:Date
        getFirst
        getLast
        getDOB
        getHIREDATE
        toSTRING
    */
}