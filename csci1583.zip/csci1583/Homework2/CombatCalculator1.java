// a game where the player creates a character and uses it to battle random monsters
//import java Random Generator
import java.util.Random;
//import java Scanner for user input
import java.util.Scanner;
//declare class
public class CombatCalculator1
{      
        
        //Initialize player level variable
        private static int playerLevel = 1;
        //Initialize player experience variable
        private static int playerExperiencePoints = 0;
        //Initialize player health variable
        private static int playerHealth = 0;
        //Initialize player attack power variable and set it to 0
        private static int playerAttackPower = 0;
        //Initialize player magic power variable and set it o 0
        private static int playerMana = 0;
        //Initialize a variable for user input
        private static int playerChoice;
        // declare and initialize the player's stat points
        private static int statPoints = 20;
        
        //Initialize monster name variable 
        private static String monsterName;
        //Initialize monster health variable and set it 0
        private static int monsterHealth = 0;
        //Initialize monster attack power variable and set it to 0
        private static int monsterAttackPower = 0;
        //Initialize monster experience point value
        private static int monsterExperienceValue;
        
        //Initialize loop control variable and set it to true
        private static boolean loopControl = true;
        private static boolean loopControl1 = true;
        
        
    //main method    
    public static void main(String[] args)
    {
        playerCreation();
        
        while (playerHealth > 0 && loopControl == true)
        {
            monsterCreation();
            runCombat();
            playerLevelUp();
        }
        
        
    }
    
    
    // create a method to hold hero creation
    public static void playerCreation()
    {
            
            // initialize a while loop to continue with the hero creation method until the player has used all of their stat points
            while (statPoints > 0 && loopControl == true)
            {
                    // print to the user their current attackpower health and magic power stats
                    System.out.printf("Health:%d, Attack:%d, Magic:%d", playerHealth, playerAttackPower, playerMana);
                    
                    
                    // print options to the user to allocate the stats of their character
                    System.out.println("\n1)  +10 Health");
                    System.out.println("2)  +1 Attack");
                    System.out.println("3)  +3 Mana");
                    System.out.printf("You have %d points to spend: ", statPoints);
                    
                    
                    // create a scanner object to get the user's input
                    Scanner input = new Scanner(System.in);
                    playerChoice = input.nextInt();
                    
                    System.out.println("");
                    
                    
                    //check with equality operator for user input
                    if (playerChoice == 1)
                    {
                        // update the players health by adding 10 health points
                        playerHealth = playerHealth + 10;
                        //deduct 1 point from the player's available stat points
                        statPoints--;
                    }
                    
                    
                    else if (playerChoice == 2)
                    {
                        //update the player's attack power by adding 1
                        playerAttackPower++;
                        //deduct 1 point from the player's available stat points
                        statPoints--;
                    }
                    
                    
                    else if (playerChoice == 3)
                    {
                        //update the player's mana by adding 3
                        playerMana = playerMana + 3;
                        //deduct 1 point from the player's available stat points
                        statPoints--;
                    }
                    
                    else
                    {
                        errorMessage();
                    }
                    
                
            }
    }
    
    
    
    
    public static void monsterCreation()
    {
            //while (loopControl == true)
            {
                    Random randomGenerator = new Random();
                    int monsterNumber = randomGenerator.nextInt(3);
                    
                    if (monsterNumber == 0)
                    {
                            monsterName = "Goblin";
                            monsterAttackPower = 8 + (randomGenerator.nextInt(4));
                            monsterHealth = 75 + (randomGenerator.nextInt(24));
                            monsterExperienceValue = 1;
                        
                    }
                    
                    else if (monsterNumber == 1)
                    {
                            monsterName = "Orc";
                            monsterAttackPower = 12 + (randomGenerator.nextInt(4));
                            monsterHealth = 100 + (randomGenerator.nextInt(24));
                            monsterExperienceValue = 3;
                            
                    }
                    
                    else if (monsterNumber == 2)
                    {
                            monsterName = "Troll";
                            monsterAttackPower = 15 + (randomGenerator.nextInt(4));
                            monsterHealth = 150 + (randomGenerator.nextInt(49));
                            monsterExperienceValue = 5;
                    }
                    
                    //report to the user what monster they have encountered
                    System.out.printf("\nYou have encountered a %s.\n", monsterName);
            }        
    }
    
    
    
    
    public static void runCombat()
    {
        //create a while loop 
        while (monsterHealth > 0 && playerHealth > 0 && loopControl == true)
        {
        //Report Combat Stats
                //Print the Monsters name
                System.out.printf("\nYou are fighting a %s!\n", monsterName);
                //Print the Monsters health
                System.out.printf("The Monster HP: %d", monsterHealth);
                //Print the player's current level to the user
                System.out.printf("\nYour Lvl: %d", playerLevel);
                //Print the pLayers health
                System.out.printf("\nYour HP: %d", playerHealth);
                //Print the players magic points
                System.out.printf("\nYour MP: %d\n", playerMana);
                
                
                //Combat menu prompt
                System.out.print("\nCombat Options:\n");
                //Print option 1: Sword Attack
                System.out.print("  1.) Sword Attack\n");
                //Print option 2: Cast Spell
                System.out.print("  2.) Cast Spell\n");
                //Print option 3: Charge Mana
                System.out.print("  3.) Charge Mana\n");
                //Print option 4: Run Away
                System.out.print("  4.) Run Away\n");
                //Prompt user for input
                System.out.print("What action do you want to perform?   ");
                
                
                        //Get player's input
                        Scanner input = new Scanner(System.in);
                        playerChoice = input.nextInt();
                        
                        
                                //if player chose option 1 check with equality operator
                                if (playerChoice == 1)
                                        {
                                                swordAttack();
                                        }
                                
                                
                                //if player chose option 2 check with equality operator
                                else if (playerChoice == 2)
                                {   
                                        //if player chose option two and has 3+ Mana points check with equality operator
                                        if (playerMana >= 3)
                                        {
                                                castSpell();
                                        }
                                        //if player chose option two and does not have 3+ mana points create an else statement
                                        else
                                        {
                                                manaError();
                                        }
                                }
                                
                                
                                //if player chose option 3 check with equality operator
                                else if (playerChoice == 3)
                                        {
                                                chargeMana();
                                        }
                                
                                
                                //if player chose option 4 check with equality operator
                                else if (playerChoice == 4)
                                        {
                                                runAway();
                                        }
                                
                                
                                //Create an else statement if the user selects an option other than those listed
                                else
                                        {
                                                errorMessage();
                                        }
                                
                                
                                //Create an if statement, if the player chose an option other than run away and the monster is still alive
                                //the monster will deal damage to the player
                                if (playerChoice != 4 && monsterHealth > 0)
                                
                                        {
                                                monsterHit();
                                        }
        
                //create an if statement, if the monster's hp is less than or equal to 0
                
                if (monsterHealth <= 0)
                {
                        //print victory message
                        playerWin();
                }
                //create an if statement, if the player's health is less than or equal to 0
                if (playerHealth <= 0)
                {
                        //print defeat message and end loop
                        playerLose();
                }
        }        
    }
    
    
    
    
    
    
    
    
    
                    public static void swordAttack()
                    {
                                    Random randomGenerator = new Random();
                                    int playerRandomAttack = randomGenerator.nextInt((playerAttackPower - 1))+1;
                                    //calculate damage and monster health using subtraction
                                    monsterHealth = monsterHealth - playerRandomAttack;
                                    //print attack message
                                    System.out.printf("\nYou strike the %s with your sword for %d damage.\n", monsterName, playerRandomAttack);
                    }
                    
                    
                    public static void castSpell()
                    {
                                    //Calculate the Monsters health by using division
                                    monsterHealth = (monsterHealth)/2;
                                    //Print attack message
                                    System.out.printf("\nYou cast the weaken spell on the monster.\n");
                                    //Cakculate the player's mp by, reduce the player's mana points by 3 using subtraction
                                    playerMana = playerMana - 3;
                    }
                    
                    
                    public static void manaError()
                    {
                                    //Print message to the player saying you do not have enough mana.
                                    System.out.print("\nYou don't have enough mana.\n");
                    }
                    
                    
                    public static void chargeMana()
                    {
                                    //Calculate the player's mana points using addition
                                    playerMana++;
                                    //Print message to user saying You focus and charge your magic power
                                    System.out.print("\nYou focus and charge your magic power.\n");
                    }
                    
                    
                    public static void runAway()
                    {
                                    //Print message to user saying You run away
                                    System.out.print("\nYou run away!\n"); 
                                    //End the while loop by setting the loop control variable to false
                                    loopControl = false;
                    }
                    
                    
                    public static void errorMessage()
                    {
                                    //Print a message to the user saying please select a valid option
                                    System.out.println("\nPlease select a valid option.");
                    }
                    
                    
                    public static void monsterHit()
                    {
                                    Random randomGenerator = new Random();
                                    int monsterAttackRandom = randomGenerator.nextInt((monsterAttackPower - 1))+1;
                                    
                                    //calculate damage and player health using subtraction
                                    playerHealth = playerHealth - monsterAttackRandom;
                                    
                                    //print monster attack message
                                    System.out.printf("\nThe %s strikes you for %d damage.\n\n", monsterName, monsterAttackRandom);
                    }
                    
                    
                    public static void playerWin()
                    {
                                    //print a victory message to the user
                                    System.out.printf("You have defeated the %s.\n", monsterName);
                    }
                    
                    
                    public static void playerLose()
                    {
                                    //set the loop control variable to false to end the while loop
                                    loopControl = false;
                                    //print a defeat message to the user
                                    System.out.printf("You have been defeated by the %s.\n", monsterName);
                    }
                    
                    
                    public static void playerLevelUp()
                    {
                        
                                // create a selection statement, do not execute the player experience increase unless the monster dies
                                if (monsterHealth <= 0)
                                {
                                        playerExperiencePoints = playerExperiencePoints + monsterExperienceValue;
                                        
                                        System.out.printf("\nYou have gained %d experience points.\n", monsterExperienceValue);
                                        //if the player has more or equal experience to their level 
                                        if (playerExperiencePoints >= playerLevel)
                                        {
                                                //reduce player xp points by the amount of their level
                                                playerExperiencePoints = playerExperiencePoints - playerLevel;
                                                //increase the player's level by 1
                                                playerLevel++;
                                                //print report to user saying hp and ap have been increased
                                                System.out.printf("\nCongratulations, you are now level %d!\nYou have gained health and attack power.\n", playerLevel);
                                                //increase player hp by 60
                                                playerHealth = playerHealth + 60;
                                                //increase player ap by 10
                                                playerAttackPower = playerAttackPower + 10;
                                        } 
                                }    
                        
                    }
    
}