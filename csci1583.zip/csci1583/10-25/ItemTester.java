public class ItemTester
{
    public static void main(String[] args)
    {
        Item item = Item.KEY;
        System.out.println(item.getDescription());
        System.out.printf("Attack: %d", item.getAttack());
        System.out.printf("Defense: %d", item.getDefense());
    }
}