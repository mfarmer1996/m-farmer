public class Date
{
    private static final int[] DAYS_PER_MONTH = 
    {0,31,28,31,30,31,30,31,31,30,31,30,31};
    //Attribute for a Date
    private int year;
    private int month;
    private int day;
    
    //constructor
    public Date(int day, int month, int year)
    {
        this.setDate(year,month,day);
    }    
    
    private void setYear(int year)
    {
        if(year<1900)
        {
            throw new IllegalArgumentException("the year must be after 1900");
        }
        this.year=year;
    }
    
    private void setMonth
    {
        if(month<=0||month>12)
        {
            throw new IllegalArgumentException("the month must be between 0-12");
        }
        this.month=month;
    }
    private void setDay
    {
        int month = this.getMonth();
        int year = this.getYear();
        if (day<=0||day>DAYS_PER_MONTH[month] && (month != 2 && day != 29)
        {
            throw new IllegalArgumentException("invalid day for month");
        }
        if(day==29 && month==2)&&!((year%4==0&&year%100!=0)||year%400==0)
        {
            throw new IllegalArgumentException("invalid day for month");
        }
        this.day=day;
    }
    //getters
    public int getYear()
    {
        return this.year;
    }
    
    public int getMonth()
    {
        return this.month;
    }
    
    public int getDay()
    {
        return this.day;
    }
    
    public String toString()
    {
        return String.format("Day: %d  Month: %d  Year:  %d", this.day, this.month, this.year);
        
    }
//getters
    
    
}
