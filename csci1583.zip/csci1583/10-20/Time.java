public class Time
{
    private int timeHour;
    private int timeMinute;
    private int timeSecond;
    
    public Time(int timeHour, int timeMinute, int timeSecond)
    {
        this.setTime(timeHour,timeMinute,timeSecond);
        
    }
    
    public void setTime(int timeHour, int timeMinute, int timeSecond)
    {
        this.setHour(timeHour);
        this.setMinute(timeMinute);
        this.setSecond(timeSecond);
    }
    
    private void setHour(int timeHour)
    {
        if(timeHour < 0 || timeHour >= 24)
        {
            throw new IllegalArgumentException("hour must be 0-23");
        }
        this.timeHour = timeHour;
    }
    
    
    
    private void setMinute(int timeMinute)
    {
        if(timeMinute < 0 || timeMinute >= 60)
        {
            throw new IllegalArgumentException("minute must be 0-60");
        }
        this.timeMinute = timeMinute;
    }
    
    private void setSecond(int timeSecond)
    {
        if(timeSecond < 0 || timeSecond >= 60)
        {
            throw new IllegalArgumentException("second must be 0-60");
        }
        this.timeSecond = timeSecond;
    }
    
    
    
    public String getUniversal()
    {
        return String.format("%02d:%02d:%02d", this.timeHour, this.timeMinute, this.timeSecond);
    }
    
    
    public String toString()
    {
        return String.format("%d:%d:%d %s:", (this.timeHour==0 || this.timeHour==12)?12:this.timeHour%12,
                                              this.timeMinute, this.timeSecond, 
                                              (this.timeHour < 12)?"AM":"PM");
    }
    
    public Time(int timeHour, int timeMinute)
    {
        this(timeHour, timeMinute, 0);
    }
    
    public Time(int timeHour)
    {
        this(timeHour, 0, 0);
    }
    
    public Time()
    {
        this(0, 0, 0);
    }
}    