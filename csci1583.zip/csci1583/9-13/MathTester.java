public class MathTester
{
    public static void main(String[] args)
    {
        double x = 100.6;
        double y = 3;
        double z = -1;
        double result;
        
        result = Math.pow(y,z);
        print(result);
    }
    
    public static void printResult(double result)
    {
        System.out.printf("%f\n", result);
    }
}