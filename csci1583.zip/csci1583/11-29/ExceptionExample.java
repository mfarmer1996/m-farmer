import java.util.InputMismatchException;
import java.util.Scanner;
public class ExceptionExample
{
    public static void main(String[] args)
    {
        boolean continueLoop = true;
        Scanner input = new Scanner(System.in);
        do{
            try
            {
                //promt user for number 1
                System.out.print("Enter numerator: ");
                //get numerator and save
                int numerator = input.nextInt();
                //prompt user for number 2
                System.out.print("Enter denominator: ");
                //save
                int denominator = input.nextInt();
                //invoke the division method
                int result = divide(numerator, denominator);
                //print result
                System.out.printf("Result is: %d", result);
                continueLoop = false;
                
            }
            
            catch (ArithmeticException e)
            {
                e.printStackTrace();
                System.out.print("The Result is Infinity\n");
                continueLoop = true;
            }
            catch (InputMismatchException ime)
            {
                System.out.print("Exception: input must be an integer\n");
                input.nextLine();
                continueLoop = true;
            }
        }while(continueLoop);    
    }
    
    public static int divide(int numerator, int denominator) throws ArithmeticException
    {
        return numerator/denominator;
    }
    
    
}