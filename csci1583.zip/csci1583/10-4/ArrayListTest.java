import java.util.ArrayList;
public class ArrayListTest
{
   //check java API for ArrayList
   public static void main(String[] args)
   {
       //generic type holds any type of data within <>
       ArrayList<String> items = new ArrayList<String>();
       items.add("red");
       display(items);
       items.add(0,"yellow");
       display(items);
       
       //print array toString takes data of the object and converts it to text data
       System.out.println(items.toString());
       
       System.out.println(items.get(0));
       
       //remove an item
       items.remove("yellow");
       System.out.println(items.toString());
       
       
       //check if list has an item
       {
           boolean b = items.contains("yellow");
           System.out.printf("That arraylist contains yellow? %b\n",b);
           
       }
       
       
   }
   
   public static void display(ArrayList<String> items)
   {
       for (String s : items)
       {
           System.out.println(s);
           
       }
   }
}