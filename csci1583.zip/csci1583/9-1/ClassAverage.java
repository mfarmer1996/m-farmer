import java.util.Scanner;
public class ClassAverage
{
    public static void main(String[] args)
    {
        //setupscannerforuserinput
        Scanner input = new Scanner(System.in);
        //variable to hold sum variable to hold count variable to hold average
        int sum = 0;
        int count = 0;
        double average;
        // while the current count is less than 10 repeat
        while (count < 10)
        {
            System.out.print("Enter a new grade: ");
            int grade = input.nextInt();
            
            count++; //increment operation
            
            sum += grade;
            
            average = (double)(sum)/count;
            
            System.out.printf("The average is %f\n", average);
            
            
        
        // create a variable to hold a single grade 
        // prompt user to enter new grade
        // get user input for that grade
        // increment our count variable
        // add the grade variable to the sum
        }
        
        
        // calculate the average
        //Report the result ot the user
        
        
    }
}