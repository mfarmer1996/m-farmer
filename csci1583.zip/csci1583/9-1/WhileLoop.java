public class WhileLoop //find the product of 3 times itself until the result is more than 100
{
    public static void main(String[] args)  //args can vary it is a variable name can be called anything args is conventional
    {
        
        // create variable set to 3
        // while product of variable is less than 100 repeat 
        int product = 3;
        while (product <100)
        {
            product = product * 3;
            System.out.printf("Product is: %d\n", product);
        }
        
        
    }
}