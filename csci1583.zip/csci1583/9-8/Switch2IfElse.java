import java.util.Scanner;
public class Switch2IfElse
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter a number1");
        int value1 = input.nextInt();
        
        System.out.println("Enter a number2");
        int value2 = input.nextInt();
        
        System.out.println("Enter a operation +, -, /, *:");
        String operation = input.next();
        
        
        if (operation.equals("+"))
            {
                System.out.printf("The sum is %d\n", sum);
            }
        else if (operation.equals("-"))
            {
                System.out.printf("The sum is %d\n", sum);
            }
            
        else if (operation.equals("/"))
            {
                System.out.printf("The sum is %d\n", sum);
            }    
        else if (operation.equals("*"))
            {
                System.out.printf("The sum is %d\n", sum);
            }
        else
            {   
                System.out.println("No such case!");
            }    
    }
}