 public class EmployeeTester
 {
     public static void main(String[] args)
     {
         Employee tim = new SalaryEmployee("Tim","Fletcher",new Date(25,12,1999), new Date(1,1,2012),10);
         System.out.println(tim);
         
         Employee kim = new SalaryEmployee("Kim","Green",new Date(5,7,1940), new Date(1,1,2012),5000);
         System.out.println(kim);
         System.out.println();
         
         Employee jim = new CommissionEmployee("Jim","Thumb",new Date(30,8,2014), new Date(31,10,2016),5000, 0.25);
         System.out.println(jim + "\n");
         
         Employee jack = new CommissionEmployee("Jack","Jackson",new Date(14,8,2016), new Date(3,11,2016),10, 0.5);
         System.out.println(jack);
         
     }
     
     public String toString()
     {
       String employee = super.toString();
       employee = employee.replace("Employee","Commission Employee");
       return String.format("%sEarning: $%.2f", employee, this.earnings());
     }
 }